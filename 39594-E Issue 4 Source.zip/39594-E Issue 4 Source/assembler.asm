
////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 1
// Author           : T. J. Keen
// Date             : 13 June 2017
//
////////////////////////////////////////////////////////////////////////////////

	
		$NOMOD51 			;disable predefined 8051 registers
		$INCLUDE (reg51atlprb2.h) 		;include CPU definition file 
		
ASSEMBLER       SEGMENT CODE
		RSEG	ASSEMBLER
             		 		
			
		PUBLIC	reboot
					
pgm_mtp         equ     0fff0h  		;IAP entry point
 
;**********************************************************************************************************************		

;routine to cause the code to vector to the 89C51 default boot loader to enable external code loading   
 
reboot:	 	mov	r7,#0		;set BLJB to 00 to force a reset to the bootloader on reset
		call	_Prog_BLJB	
	
		mov	r7,#0xff
		call	_Prog_BSB	;program the BSB (boot status byte) to 0xff to cause entry into bootloder on next reset

		mov	r7,#0xfC
		call	_Prog_SBV	;program the SBV (software boot vector) to 0xfC to cause entry into bootloder on next reset
		
		;force a software reset

		MOV 	WDTRST,#05Ah
		MOV 	WDTRST,#0A5h
		
		jmp $

;**********************************************************************************************************************		

;routine to program the SBV(software boot vector) of the microcontroller

_Prog_SBV:     	clr	ea		;datasheet states to disable interrupts prior to IAP call
	
		orl     auxr1,#20h      ;set the ENBOOT bit to map the ROM code into the address space.

                mov     r1,#06h         ;program status byte or boot vector       
  
		mov	dph,#00h
		mov	dpl,#01h	;specify boot vector
  
             	mov     a,r7            ;get user boot vector 	
       		lcall   pgm_mtp         ;execute the function
		
		anl 	auxr1,#not 20h	;ENBOOT bit should now be clear again		
	
		mov 	FCON,#00h	;re-map the code space (should have been done by pgm_mtp call!)

		setb	ea
               	ret

;***************************************************************************************

;routine to program the BSB(boot status byte) of the microcontroller 

_Prog_BSB:  	clr	ea		;datasheet states to disable interrupts prior to IAP call

		orl     auxr1,#20h      ;set the ENBOOT bit to map the ROM code into the address space.

                mov     r1,#06h         ;program status byte or boot vector       
  
		mov	dph,#00h
		mov	dpl,#00h	;specify status byte
                
              	mov     a,r7            ;get user status byte			
                lcall   pgm_mtp         ;execute the function
	
		anl 	auxr1,#not 20h	;ENBOOT bit should now be clear again	

		mov 	FCON,#00h	;re-map the code space (should have been done by pgm_mtp call!)

		setb	ea
              	ret

;***************************************************************************************

;routine to program the BLJB fuse of the microcontroller 

_Prog_BLJB:  	clr	ea		;datasheet states to disable interrupts prior to IAP call

		orl     auxr1,#20h      ;set the ENBOOT bit to map the ROM code into the address space.

                mov     r1,#0Ah         ;program BLJB fuse
  
		mov	dph,#00h
		mov	dpl,#04h	;specify BLJB fuse
                
              	mov     a,r7            ;get user value(00 or 01)			
                lcall   pgm_mtp         ;execute the function
	
		anl 	auxr1,#not 20h	;ENBOOT bit should now be clear again	

		mov 	FCON,#00h	;re-map the code space (should have been done by pgm_mtp call!)

		setb	ea
              	ret

;***************************************************************************************
		
			end


