import sys
   
assert sys.version_info >= (3,)

if len(sys.argv) < 3:
   sys.stderr.write("Error: %s requires 2 arguments: input map file and output map file" % sys.argv[0])
   sys.exit(1)

try:
    indata = bytearray()
    outdata = bytearray()

    # Prefix the map with 208 null chars for the header
    for i in range(0,208):
       outdata.append(0)

    # Read the compressed map data from the file 
    with open(sys.argv[1], 'rb') as infile:
        indata = bytearray(infile.read())
          
    print ("Bytes read from compressed map file: %d" % len(indata))

    # Transfer the first 8 bytes directly to the output 
    for i in range(0,8):
       outdata.append(indata[i])

    # The remaining bytes must be unpacked
    for byte in indata[8:]:
       for bit in range(0,8):
          outdata.append(byte & 1)
          byte >>= 1

    # Write the normalised/decompressed map data back to the file
    outfile = open(sys.argv[2], 'wb')
    outfile.write(outdata)
    outfile.close()

    print ("Bytes written to map file: %d" % len(outdata))
       
except:
    sys.stderr.write("Error in map_decompress.py")

    sys.exit(1)