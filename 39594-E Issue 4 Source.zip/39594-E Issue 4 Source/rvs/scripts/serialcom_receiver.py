import argparse
import serial
import sys
from PyCRC.CRC16 import CRC16
from struct import *

assert sys.version_info >= (3,)

def parse_cmdline():
   parser = argparse.ArgumentParser(description='Serial communications map data receiver')
   parser.add_argument('port', help='Com port to use for receiving data.')
   parser.add_argument('baud', type=int, help='Baud rate. Valid values are 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200.')
   parser.add_argument('wait', type=int, help='Wait n seconds after the last byte was received to exit.')
   parser.add_argument('outfile', help='Map output filename')
   parser.add_argument('unlock', type=int, help='0 = do not send unlock code, 1 = do send unlock code, 2 = do send unlock and enter bootloader')
   args = parser.parse_args()
   return args

try:
    args = parse_cmdline()
    
    # Initialise the serial port as per the command line parameters
    ser = serial.Serial(port=args.port, baudrate=args.baud, timeout=args.wait, xonxoff=False, rtscts=False, dsrdtr=False)
    
    # Conditionally send the unlock code and either 'DUMP COVERAGE' command (!99) or 'MICRO BOOTLOADER' command (!50)
    # See document "Factory Test Mode ICD For the 7-1600 LCU" (document reference: 1725-(Fact_Test)-14) for details of
    # factory test commands
    if (args.unlock):
    
        # Send the unlock string to the target and readback the echoed line
        b = bytearray()
        b.extend(map(ord,'!04001020400055AAFF\r\n'))
        ser.write(b)
        print(ser.readline())

        if (args.unlock == 1):
            # Send the 'DUMP COVERAGE' command to initite RVS_Output()
            b = bytearray()
            b.extend(map(ord,'!99\r'))
            ser.write(b)
            # Readback the 'DUMP COVERAGE' command echo
            ser.read(4)
        else:
            # Send the 'MICRO BOOTLOADER' command to initite RVS_Output() and then enter micro's bootloader
            b = bytearray()
            b.extend(map(ord,'!50\r'))
            ser.write(b)
            # Readback the 'MICRO BOOTLOADER' command echo
            ser.read(4)
            # Readback characters output by 'MICRO BOOTLOADER' command handler
            ser.read(9)

    # Read the map data from the target and write it to a bytearray
    mapdata = bytearray()
    
    while True:
        byte = ser.read(1)
        if (byte):
           ser.timeout=1
           mapdata.append(ord(byte))
           print (byte)
        else:
          break
    
    # Look for the byte order sequence in the map and remove any bytes before it
    startOfMap = mapdata.find(b'\x01\x02\x03\x04')
    
    if startOfMap < 0:

        # Report error condition
        sys.stderr.write("ERROR: Could not find starting sequence in coverage map\n")
        sys.exit(1)

    mapdata = mapdata[startOfMap:]

    # Get CRC and remove CRC from end of map data
    remoteCrc = unpack('>H', mapdata[-2:])[0] 
    mapdata = mapdata[:-2]

    localCrc = CRC16(True).calculate(bytes(mapdata))

    if remoteCrc != localCrc:

        # Report error condition
        sys.stderr.write("ERROR: received CRC does not match locally calculated CRC:\n")
        sys.stderr.write("       Coverage map CRCs: received = %d, calculated = %d" % (remoteCrc, localCrc))
        sys.exit(1)

    #  Read the map size from the 32-bit map size field in the recieved data
    mapsize=0
    for ix in range(4,8):
        #print("Index: %d, Value: %d" % (ix,mapdata[ix]))
        mapsize = (mapsize*256) + mapdata[ix]
    
    print ("Map size field: %08x" %len(mapdata))

    # Calulate the number of bytes we expected to recieve based on the map size field
    expectedDataSize = ((mapsize-208-8)/8)+8
    
    # Check if the correct number of bytes was recieved...
    if expectedDataSize == len(mapdata):

        # Output the collected mapdata to the output file
        print ("Recieved %d bytes from target" % len(mapdata))
        outfile = open(args.outfile, 'wb')
        outfile.write(mapdata)
        outfile.close()

    else:

        # Report error condition
        sys.stderr.write("ERROR: incorrect number of bytes read from target:\n")
        sys.stderr.write("       expected: %d, recieved: %d" % (expectedDataSize, len(mapdata)))
        sys.exit(1)
        
except Exception as inst:
    sys.stderr.write("Error in serialcom_receiver.py\n")
    sys.stderr.write(str(type(inst)))
    sys.stderr.write(str(inst.args))
    sys.stderr.write(str(inst))
    sys.exit(1)

