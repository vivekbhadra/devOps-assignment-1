##############################################################################
#    COPYRIGHT 2018 CHELTON LTD TRADING AS COBHAM AEROSPACE CONNECTIVITY
#                          ALL RIGHTS RESERVED
#
#   No part of this document may be photocopied or otherwise reproduced
#   without the prior permission in writing of Cobham Technical Services Ltd.
#   Such written permission must also be obtained before any part
#   of this document is stored in a retrieval system of whatsoever nature
#
##############################################################################
#
# Description: Script for checking the maximum i-point contained in a 
#              specified coverage database does not exceed a specified limit
#              The script will exit with a code 1 if the limit is exceeded
#
##############################################################################

import sys
import sqlite3
import argparse

assert sys.version_info >= (3,)

def parse_cmdline():
    parser = argparse.ArgumentParser(description='RVS maximum i-point checker')
    parser.add_argument('rvdfile', help='filename of the coverage results database (*.rvd)')
    parser.add_argument('max_ipoint', type=int, help='Value to check maximum i-point against')
    args = parser.parse_args()
    return args

try:
    args = parse_cmdline()

    rvdDatabase = sqlite3.connect('coverage.rvd')

    results = rvdDatabase.execute('select max(number) from instrumentationpoint;')

    maxIpoint = results.fetchone()[0]

    if maxIpoint > args.max_ipoint:
        sys.stderr.write(f"ERROR: The maximum i-point value contained in the coverage database exceeds the value specified\n")
        sys.stderr.write(f"       Max i-point in coverage database: {maxIpoint}\n")
        sys.stderr.write(f"       Limit specified for i-point: {args.max_ipoint}\n")
        sys.exit(1)
    else:
        print(f"The maximum i-point value found in '{args.rvdfile}' is: {maxIpoint}")
        print(f"This is within the limit specified of: {args.max_ipoint}")

except Exception as inst:
    sys.stderr.write("Error in check_max_ipoint.py\n")
    sys.stderr.write(str(type(inst)))
    sys.stderr.write(str(inst.args))
    sys.stderr.write(str(inst))
    sys.exit(1)