import sys

assert sys.version_info >= (3,)

if len(sys.argv) < 2:
   print "Error: %s requires an argument of the map file to process" % sys.argv[0]
   sys.exit()

try:
    outdata = []

    # Prefix the map with 208 null chars for the MCDC data
    for i in range(0,208):
       outdata.append('\0')

    # Read the map data from the file in to the outdata list
    with open(sys.argv[1], 'rb') as infile:
       char = infile.read(1)
       while char != b"":
          outdata.append(char)
          char = infile.read(1)

    infile.close()

    # Write the updated map data to the map data output file
    outfile = open(sys.argv[1], 'wb')
    for char in outdata:
       outfile.write(char)
    outfile.close()

except:
    print("Error in map_restore.py")