##############################################################################
#    COPYRIGHT 2018 CHELTON LTD TRADING AS COBHAM AEROSPACE CONNECTIVITY
#                          ALL RIGHTS RESERVED
#
#   No part of this document may be photocopied or otherwise reproduced
#   without the prior permission in writing of Cobham Technical Services Ltd.
#   Such written permission must also be obtained before any part
#   of this document is stored in a retrieval system of whatsoever nature
#
##############################################################################
#
# Description: Script for checking that the coverage map templates installed
#              in the RVS installation match those supplied with the
#              integration
#
##############################################################################

import sys
from os import path
import argparse
import hashlib
import binascii

assert sys.version_info >= (3,)

def parse_cmdline():
    parser = argparse.ArgumentParser(description='RVS Coverage Map Template Signature Checker')
    parser.add_argument('rvsbinpath', help='Path to the bin directory installation of RVS')
    parser.add_argument('covmap', help='Name of the coverage map')
    parser.add_argument('--integration', default='rvs', help='Path to the RVS integration (default = "rvs")')
    args = parser.parse_args()
    return args

try:
    args = parse_cmdline()

    print(f"RVS bin path: {args.rvsbinpath}")
    print(f"Coverage map: {args.covmap}")
    print(f"Integration path: {args.integration}")
    print("")


    covmapRvsPath = path.join(args.rvsbinpath, 'covmap', args.covmap)
    covmapIntegrationPath = path.join(args.integration, 'covmap', args.covmap)

    templates = ["template_c_normal_c.template", "template_c_normal_h.template"]

    for templateFileName in templates:
        print(f"Checking template file: {templateFileName}")

        rvsTemplateFullPath = path.join(covmapRvsPath, templateFileName)
        integrationTemplateFullPath = path.join(covmapIntegrationPath, templateFileName)

        rvsTemplateHash = hashlib.sha256()
        integrationTemplateHash = hashlib.sha256()

        with open(rvsTemplateFullPath, 'rb') as templateFile:
            rvsTemplateHash.update(templateFile.read())

        with open(integrationTemplateFullPath, 'rb') as templateFile:
            integrationTemplateHash.update(templateFile.read())

        rvsHash = binascii.hexlify(rvsTemplateHash.digest()).decode()
        integrationHash = binascii.hexlify(integrationTemplateHash.digest()).decode()

        print(f"Hash for installed template  = {rvsHash}")
        print(f"Hash for intgration template = {integrationHash}")

        if rvsTemplateHash.digest() == integrationTemplateHash.digest():
            print(f"Hashes match")
        else:
            # Report error condition
            sys.stderr.write( "ERROR: The hash of the installed coverage map template does not match the template supplied with the integration\n")
            sys.stderr.write( "       Please ensure that the coverage templates in the RVS installation match those supplied with the integration\n")
            sys.stderr.write(f"       Template file name: {templateFileName}\n")
            sys.exit(1)

        print()
    
except Exception as inst:
    sys.stderr.write("Error in check_templates.py\n")
    sys.stderr.write(str(type(inst)))
    sys.stderr.write(str(inst.args))
    sys.stderr.write(str(inst))
    sys.exit(1)