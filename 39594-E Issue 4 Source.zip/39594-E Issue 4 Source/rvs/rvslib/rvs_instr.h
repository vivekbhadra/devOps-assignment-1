/* Subprogram specific RVS instr pragmas
   This file will be included in instrumented source (-c) */
#pragma RVS default_instrument("TRUE", "COV_178_DAL_C");