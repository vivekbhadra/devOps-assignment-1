/* Subprogram specific RVS instr pragmas
   This file will be included in instrumented source (-c) */
#pragma RVS default_instrument("FALSE", "COV_178_DAL_C")
#pragma RVS instrument("+filename:*rvs_rpc_q*", "TRUE" )
#pragma RVS instrument("rvs_rpc_qtest_c", "FALSE" )