////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 4
// Author           : T. J. Keen
// Date             : 13 June 2017
//
////////////////////////////////////////////////////////////////////////////////

#ifndef HAL_H
#define HAL_H

#include "reg51atlprb2.h"        					// special function register declarations for micro

////////////////////////////////////////////////////////////////////////////////
//
// Local Defines
//
////////////////////////////////////////////////////////////////////////////////

#define PLD_BASE_ADDR			                     0x8000U ///< Memory mapped address of PLD registers
#define VOLTAGE_STATE 1

// PLD 8-bit Register Addresses as defined in Cobham document 1725-(39565M)-14
#define PLD_REG_CPLD_RADIO		                 PLD_BASE_ADDR + 0
#define PLD_REG_CONTROL_1		                   PLD_BASE_ADDR + 1
#define PLD_REG_STATUS_2		                   PLD_BASE_ADDR + 2
#define PLD_REG_SECTOR_LATCH	                 PLD_BASE_ADDR + 4	 ///< Parallel Flash sector address register
#define PLD_REG_ANTDRIVE_LOW 	                 PLD_BASE_ADDR + 5	 ///< Antenna output drive for test
#define PLD_REG_ANTDRIVE_HIGH	                 PLD_BASE_ADDR + 6
#define PLD_REG_POWER_UP		                   PLD_BASE_ADDR + 7
#define PLD_REG_INTERFACE_VERSION              PLD_BASE_ADDR + 8
#define PLD_REG_ISSUE_NUMBER                   PLD_BASE_ADDR + 11
#define PLD_REG_SOFTWARE_NO_LSB                PLD_BASE_ADDR + 12
#define PLD_REG_SOFTWARE_NO_MSB                PLD_BASE_ADDR + 13
#define PLD_REG_CRC_CONTROL                    PLD_BASE_ADDR + 14
#define PLD_REG_TABLE_CRC_LSB                  PLD_BASE_ADDR + 15
#define PLD_REG_TABLE_CRC_MSB                  PLD_BASE_ADDR + 16

// PLD CPLD_RADIO Register field masks
#define PLD_CPLD_RADIO_RSEL                    0x07U
#define PLD_CPLD_RADIO_ASEL                    0x18U
#define PLD_CPLD_RADIO_LINES                   0x60U
#define PLD_CPLD_RADIO_RADIO_PRESET_VALID      0X80U

// PLD CONTROL_1 Register field masks
#define PLD_CONTROL_1_CPLD_MODE                0x01U
#define PLD_CONTROL_1_MICRO_LED                0x02U
#define PLD_CONTROL_1_PSU_LED                  0x04U
#define PLD_CONTROL_1_CPLD_LED                 0x08U
#define PLD_CONTROL_1_PBIT_FAIL                0x10U
#define PLD_CONTROL_1_SINGLE_ENDED             0x20U
#define PLD_CONTROL_1_FLASH_RESET              0x40U
#define PLD_CONTROL_1_TX_ENABLED               0x80U

// PLD STATUS 2 Register field masks
#define PLD_REG_STATUS_2_DRIVER_BIT            0x01U
#define PLD_REG_STATUS_2_PSU_BIT               0x02U
#define PLD_REG_STATUS_2_ETI_ALARM             0x04U
#define PLD_REG_STATUS_2_JTAG_STARTUP_FAIL     0x08U
#define PLD_REG_STATUS_2_RADIO_IF_ERROR        0x10U
#define PLD_REG_STATUS_2_JTAG_STATUS           0x20U
#define PLD_REG_STATUS_2_TXD_EN                0x40U
#define PLD_REG_STATUS_2_CPLD_FLASH_BUSY       0x80U

// PLD CRC Control Register bit masks
#define PLD_REG_CRC_CONTROL_CRC_1             0x01U
#define PLD_REG_CRC_CONTROL_CRC_2             0x02U
#define PLD_REG_CRC_CONTROL_CRC_3             0x04U
#define PLD_REG_CRC_CONTROL_CRC_4             0x08U
#define PLD_REG_CRC_CONTROL_CRC_RADIO_PRESETS 0x10U
#define PLD_REG_CRC_CONTROL_TABLE0            0x20U
#define PLD_REG_CRC_CONTROL_TABLE1            0x40U
#define PLD_REG_CRC_CONTROL_CHECK_CRC         0x80U

///////////////////////////////////////////////////////////////////////////////////

// I2C SSCON register flags
#define ASSERT_ACK_FLAG                        0x04U  ///< AA Assert acknowledge flag
#define INT_FLAG                               0x08U  ///< SI interrupt flag
#define STOP_FLAG                              0x10U  ///< STO stop flag
#define START_FLAG                             0x20U  ///< STA start flag

#define I2C_ETI_ADDRESS                        0xD6U  ///< I2C Address for DS1682 ETI
#define I2C_EXPANDER_ADDRESS                   0x70U  ///< I2C Address for Texas PCF8574A bus expander

#define I2C_READ                               1
#define I2C_WRITE                              0
#define I2C_NACK                               1

#define SPIF_BIT                               0x80U  ///< SPIF bit 7 of SPI status register

// 23LC1024 128Kbyte SPI RAM command codes
#define SPI_WRITE                              0x02U  ///< write to memory array
#define SPI_READ 	                           0x03U  ///< read from memory array
#define SPI_RDMR 	                           0x05U  ///< read Mode register
#define SPI_WRMR 	                           0x01U  ///< write Mode register

///////////////////////////////////////////////////////////////////////////////////

// JTAG source select definitions
#define JTAG_SOURCE_J1                         0x79U  ///< Value for bus expander for JTAG to J1
#define JTAG_SOURCE_PCB                        0x7FU  ///< Value for bus expander for JTAG to PCB

///////////////////////////////////////////////////////////////////////////////////

// Parallel FLASH memory defines
#define FLASH_MAX_SECTORS                      141U   ///< The parallel FLASH memory has 141 sectors
#define FLASH_SECTOR_0                         0x00U
#define FLASH_SECTOR_7                         0x07U
#define FLASH_SECTOR_8                         0x08U
#define FLASH_SECTOR_9                         0x09U
#define FLASH_SECTOR_10                        0x0AU

#define FLASH_SECTOR_133                       0x85U
#define FLASH_SECTOR_134                       0x86U
#define FLASH_SECTOR_141                       0x8DU

#define FLASH_DQ5                              0x20U

#define FLASH_SECTOR_8_ADDRESS                 0x010000U   ///< Flash memory sector 8 start address (byte mode)
#define FLASH_SECTOR_9_ADDRESS                 0x020000U   ///< Flash memory sector 9 start address (byte mode)
#define FLASH_SECTOR_10_ADDRESS                0x030000U   ///< Flash memory sector 9 start address (byte mode)
#define FLASH_LAST_ADDRESS                     0x7FFFFFU   ///< Flash memory address of last location (byte mode)

///////////////////////////////////////////////////////////////////////////////////

// UART

// UART baud rates
#define BAUD_9600 			0X00U
#define BAUD_19200			0X01U
#define BAUD_38400			0X02U
#define BAUD_57600			0X03U
#define BAUD_115200			0X04U

// Circular Factory Test transmit buffer
#define TRANSMIT_BUFFER_SIZE    50U
#define TRANSMIT_BUFFER_START   16U
#define TRANSMIT_BUFFER_END     TRANSMIT_BUFFER_START + TRANSMIT_BUFFER_SIZE - 1

// Linear Factory Test command buffer
#define COMMAND_BUFFER_SIZE  110U
#define COMMAND_BUFFER_START 80U              // line buffer start

// Micro-controller port pins
sbit MemoryPldSelect      = P1^1;             // for selecting either flash memory or CPLD latches for access
sbit RamCS                = P4^3;
sbit CpldReady            = P3^2;
sbit nFlashBusy           = P3^4;
sbit DriverBitOk          = P3^5;

///////////////////////////////////////////////////////////////////////////////////
//
// Function prototypes
//
///////////////////////////////////////////////////////////////////////////////////

// Micro-controller initisalisation
void HAL_MicroInit(void);

// UART peripheral functions
void HAL_UartInit(unsigned char baud);
unsigned char HAL_UartGetHexPair(char position);
void HAL_UartPutChar(char ch);
void HAL_UartPrintHex(long number, unsigned char numDigits);
unsigned char HAL_UartWriteCommandBufferToFlash(unsigned long address);
unsigned char HAL_CommandBufferNumberOfArgs(void);
void HAL_FlushCommandBuffer(void);

// Functions to read and write to the PLD's registers
void HAL_PldWriteLatch(unsigned int address, unsigned char value);
unsigned char HAL_PldReadLatch(unsigned int address);
void HAL_PldLatchSetBitMask(unsigned int address, unsigned char mask);
void HAL_PldLatchClearBitMask(unsigned int address, unsigned char mask);

void HAL_PldWaitForReady(void);
unsigned char HAL_PldIsCompatible(void);
void HAL_AssertRadioBit(void);
void HAL_PldSetAsMaster(void);
unsigned char HAL_FactoryTestSelected(void);
unsigned char HAL_WarmStartDetected(void);
void HAL_SetWarmStartFlag(void);
unsigned char HAL_GetNumAntennaLines(void);
unsigned char HAL_GetWorkingAntennaTable(void);

// Functions to access external flash device
unsigned char HAL_FlashEraseChip();
unsigned char HAL_FlashWrite(unsigned long address, unsigned char value);
unsigned char HAL_FlashWriteAndVerify(unsigned long address, unsigned char WriteByte);
unsigned char HAL_FlashRead(unsigned long address);
unsigned char HAL_FlashReadyWait(unsigned char sector, unsigned int shortAddress);
unsigned char HAL_FlashEraseSector(unsigned char sector);
void HAL_FlashReset(void);

// Function to access the 128K SPI RAM device
unsigned char HAL_RamRead(unsigned char addressHighByte,
                          unsigned char addressMidByte,
                          unsigned char addressLowByte);
void HAL_RamWrite(unsigned char addressHighByte,
                  unsigned char addressMidByte,
                  unsigned char addressLowByte,
                  unsigned char value);

// SPI peripheral functions
unsigned char HAL_SpiTransfer(unsigned char value);

// I2C peripheral functions
void HAL_I2cWriteByte(unsigned char value);
unsigned char HAL_I2cReadByte(unsigned char assertAcknowledge);
void HAL_I2cRepeatStart(void);

// ETI device functions
unsigned char HAL_EtiReadReg(unsigned char address);
void HAL_EtiWriteReg(unsigned char address, unsigned char value);

// Bus expander device functions
void HAL_BusExpanderWrite(unsigned char value);

// LED control functions
void HAL_SetInputLed(unsigned char on);
void HAL_SetOutputLed(unsigned char on);
void HAL_SetPcbLed(unsigned char on);

void HAL_FlashInputLed(unsigned char enabled);

// Utility functions
void HAL_Delay2ms(void);

#endif // HAL_H