////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 4
// Author           : T. J. Keen
// Date             : 13 June 2017
//
// Description      : Module bit.c provides a set of functions that are designed 
//                    to test the LCU's hardware both at start-up and during 
//                    normal operation. Functions are also provided to validate 
//                    the integrity of loaded data.
//
////////////////////////////////////////////////////////////////////////////////

#include "bit.h"
#include "hal.h"

#include "common_types.h"

#define BIT_FAILURE_NONE                0xFFU

#define BIT_FAILURE_DRIVE_LINES         0x01U
#define BIT_FAILURE_JTAG_SWITCH         0x02U
#define BIT_FAILURE_ANTENNA_TABLE       0x04U
#define BIT_FAILURE_RADIO_PRESETS       0x08U
#define BIT_FAILURE_RADIO_DECODER       0x10U
#define BIT_FAILURE_PSU                 0x20U

#define BIT_LOG_MAX_ENTRIES             100U

#define DRIVE_LINE_TEST_PATTERN_COUNT   21U

////////////////////////////////////////////////////////////////////////////////
//
// Local function prototype declarations
//
////////////////////////////////////////////////////////////////////////////////

// BIT Checker Functions
static unsigned char BIT_CheckAntennaDriveLines(void);
static unsigned char BIT_CheckJtagRoutingSwitches(void);
static unsigned char BIT_CheckWorkingAntennaTableValid(void);
static unsigned char BIT_CheckRadioPresetsValid(void);
static unsigned char BIT_CheckRadioDecoderTypeValid(void);
static unsigned char BIT_CheckPsu(void);

// BIT Failure Log Functions
static void BIT_WriteToLog(unsigned char bitLogEntry);

////////////////////////////////////////////////////////////////////////////////
//
// Function defintions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Main entry point for running PBIT checks
///
/// Runs the software PBIT checks. If a check fails then
/// the J1 Radio Fault line is asserted (via the PLD reguster
/// interface) and the BIT failures are logged to flash.

void BIT_RunPbit(void)
{
  unsigned char bitFailures = (BIT_FAILURE_NONE);

  if (BIT_CheckAntennaDriveLines() != SUCCESS)
  {
    bitFailures &= ~(BIT_FAILURE_DRIVE_LINES);
  }

  if (BIT_CheckJtagRoutingSwitches() != SUCCESS)
  {
    bitFailures &= ~(BIT_FAILURE_JTAG_SWITCH);
  }

  if (BIT_CheckWorkingAntennaTableValid() != SUCCESS)
  {
    bitFailures &= ~(BIT_FAILURE_ANTENNA_TABLE);
  }

  if (BIT_CheckRadioPresetsValid() != SUCCESS)
  {
    bitFailures &= ~(BIT_FAILURE_RADIO_PRESETS);
  }

  if (BIT_CheckRadioDecoderTypeValid() != SUCCESS)
  {
    bitFailures &= ~(BIT_FAILURE_RADIO_DECODER);
  }

  if (BIT_CheckPsu() != SUCCESS)
  {
    bitFailures &= ~(BIT_FAILURE_PSU);
  }

  if (bitFailures != (BIT_FAILURE_NONE))
  {
    HAL_AssertRadioBit();
    BIT_WriteToLog(bitFailures);
  }
}

/// \brief BIT Check: Checks Antenna Driver Output Card
///
/// BIT check tests the output Antenna Driver Output Card
/// with "walking 1's", "walking 0's", all high and all low
/// test patterns. All nine drive lines are tested, if a
/// seven or eight line antenna is connected the driver
/// card automatically excludes the unused lines from the
/// test.
///
/// \return Returns 1 if Antenna Driver Card can drive the
///         Antenna Lines correctly, otherwise returns 0

static unsigned char BIT_CheckAntennaDriveLines(void)
{
  unsigned char result;
  unsigned char numberOfDriveLines;
  unsigned char driveLowData;
  unsigned char i;

  // DEVIATION - Rule 5.6.4 - "code" storage specifier used in place of const
  unsigned char code Pattern[DRIVE_LINE_TEST_PATTERN_COUNT][2] =
  { {0X00,0X80},      // All "0"
    {0X02,0X80},      // J voltage
    {0X04,0X80},      // A voltage
    {0X08,0X80},      // B voltage
    {0X10,0X80},      // C voltage
    {0X20,0X80},      // D voltage
    {0X40,0X80},      // E voltage
    {0X80,0X80},      // F voltage
    {0X00,0X81},      // H voltage
    {0X01,0X80},      // K voltage
    {0XFF,0X81},      // All "1"
    {0XFD,0X81},      // J current
    {0XFB,0X81},      // A current
    {0XF7,0X81},      // B current
    {0XEF,0X81},      // C current
    {0XDF,0X81},      // D current
    {0XBF,0X81},      // E current
    {0X7F,0X81},      // F current
    {0XFF,0X80},      // H current
    {0XFE,0X81},      // K current
    {0XFF,0X81},      // All "1"
  };

  result = SUCCESS;

  numberOfDriveLines = HAL_GetNumAntennaLines();

  if (numberOfDriveLines != 0)
  {
    for (i = 0; i < (DRIVE_LINE_TEST_PATTERN_COUNT); i++)
    {
      driveLowData = Pattern[i][1];

      if (numberOfDriveLines == 8)
      {
        driveLowData |= 0x04;                       // set bit 2(Lines 0)
      }
      else if (numberOfDriveLines == 9)
      {
        driveLowData |= 0x08;                       // set bit 3(Lines 1)
      }
      else
      {
        // Do nothing
      }

      HAL_PldWriteLatch(PLD_REG_ANTDRIVE_HIGH, Pattern[i][0]);
      HAL_PldWriteLatch(PLD_REG_ANTDRIVE_LOW,  driveLowData);

      HAL_Delay2ms();                              // delay for the driver card outputs to settle

      if (DriverBitOk != 0)                        // grounded for good state
      {
        result = FAIL;
        break;
      }
    }

    // Disable micro control of drive lines
    HAL_PldWriteLatch(PLD_REG_ANTDRIVE_LOW, 0x00);
  }
  else
  {
    result = FAIL;
  }

  return result;
}

/// \brief BIT Check: Checks JTAG is not routed to J1
///
/// BIT check tests whether the PLD JTAG interface is
/// routed to internal header and not the J1 ASEL lines.
/// The JTAG routing state is read from the PLD register
/// interface.
///
/// \return Returns 1 if JTAG is not routed to J1,
///         otherwise returns 0

static unsigned char BIT_CheckJtagRoutingSwitches(void)
{
  unsigned char result;
  unsigned char pldRegisterValue;

  pldRegisterValue = HAL_PldReadLatch(PLD_REG_STATUS_2);

  if ((pldRegisterValue & PLD_REG_STATUS_2_JTAG_STARTUP_FAIL) > 0)
  {
    result = FAIL;
  }
  else
  {
    result = SUCCESS;
  }

  return result;
}

/// \brief BIT Check: Checks validity of Working Antenna Table
///
/// BIT check tests whether the Working Antenna Table stored
/// in flash is valid and compatible. The validity (CRC) and
/// compatibility of the Working Antenna Table is checked by
/// PLD on power-up, which sets the CRC bit corrosponding to
/// the Workng Antenna Table in the PLD CRC_CONTROL register
/// with the result (1 = valid and compatible, otherwise 0).
/// This function reads the value of the CRC flag for the
/// Working Antenna Table from the PLD and returns the result.
///
/// \return Returns 1 if Working Antenna Table is valid,
///         otherwise returns 0

static unsigned char BIT_CheckWorkingAntennaTableValid(void)
{
  unsigned char result;
  unsigned char workingAntennaTable;
  unsigned char pldRegisterValue;
  unsigned char antennaCrcMask;

  workingAntennaTable = HAL_GetWorkingAntennaTable();

  pldRegisterValue = HAL_PldReadLatch(PLD_REG_CRC_CONTROL);

  antennaCrcMask = (0x01 << workingAntennaTable);

  if ((pldRegisterValue & antennaCrcMask) == 0)
  {
    result = FAIL;
  }
  else
  {
    result = SUCCESS;
  }

  return result;
}

/// \brief BIT Check: Checks validity of Radio Presets
///
/// BIT check tests whether the Radio Presets stored in
/// flash are valid and compatible. The validity (CRC) and
/// compatibility of the Radio Presets is checked by the
/// PLD on power-up, which sets the CRC Radio Preset bit
/// in the PLD CRC_CONTROL register with the result
/// (1 = valid and compatible, otherwise 0). It also
/// checks that the Radio Decoder Type selected by the
/// RSEL lines is a valid value by reading the Radio IF
/// Error bit in the PLD STATUS_2 register.
///
/// \return Returns 1 if Radio Presets is valid,
///         otherwise returns 0

static unsigned char BIT_CheckRadioPresetsValid(void)
{
  unsigned char result;
  unsigned char pldRegisterValue;

  pldRegisterValue = HAL_PldReadLatch(PLD_REG_CPLD_RADIO);

  if ((pldRegisterValue & PLD_CPLD_RADIO_RADIO_PRESET_VALID) == 0)
  {
    result = FAIL;
  }
  else
  {
    result = SUCCESS;
  }

  return result;
}

/// \brief BIT Check: Checks validity of Radio Type
///
/// BIT check tests whether the selected Radio Decoder
/// Type (based on RSEL lines and Radio Decoder Type
/// stored in Radio Presets) is a valid value by reading
/// the Radio IF Error bit in the PLD STATUS_2 register.
///
/// \return Returns 1 if Radio Decoder Type is valid,
///         otherwise returns 0

static unsigned char BIT_CheckRadioDecoderTypeValid(void)
{
  unsigned char result;
  unsigned char pldRegisterValue;

  pldRegisterValue = HAL_PldReadLatch(PLD_REG_STATUS_2);

  if ((pldRegisterValue & PLD_REG_STATUS_2_RADIO_IF_ERROR) != 0)
  {
    result = FAIL;
  }
  else
  {
    result = SUCCESS;
  }

  return result;
}

/// \brief BIT Check: Checks PSU BIT state
///
/// BIT check tests whether the PSU board is reporting
/// a BIT fault. The PSU BIT status is accessed via
/// the PSU BIT flag in the PLD regiter PLD STATUS_2.
///
/// \return Returns 1 if PSU is not reporting a fault,
///         otherwise returns 0

static unsigned char BIT_CheckPsu(void)
{
  unsigned char result;
  unsigned char pldRegisterValue;

  pldRegisterValue = HAL_PldReadLatch(PLD_REG_STATUS_2);

  if ((pldRegisterValue & PLD_REG_STATUS_2_PSU_BIT) > 0)
  {
    result = FAIL;
  }
  else
  {
    result = SUCCESS;
  }

  return result;
}

/// \brief Logs PBIT failures to PBIT Failure Log
///
/// Logs PBIT failures to PBIT Failure Log stored in
/// external flash memory. The log has entries for up
/// to 100 PBIT failures, once this limit is reached
/// PBIT failures are no longer logged. Each entry is
/// written to the next availble byte in the log until
/// the log limit is reached. The log is stored in
/// sector 8 of flash memory.
///
/// \param  bitLogEntry Mask of BIT results to log

static void BIT_WriteToLog(unsigned char bitLogEntry)
{
  unsigned long flashAddress;
  unsigned char flashValue;
  unsigned char i;

  for (i = 0; i < (BIT_LOG_MAX_ENTRIES); i++)
  {
    flashAddress = FLASH_SECTOR_8_ADDRESS + (unsigned long)i;

    flashValue = HAL_FlashRead(flashAddress);

    // stop on the first unused entry encountered
    if (flashValue == (BIT_FAILURE_NONE))
    {
      HAL_FlashWrite(flashAddress, bitLogEntry);
      break;
    }
  }
}
