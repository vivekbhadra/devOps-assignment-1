::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Remove transient build artefacts
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
CALL env.bat

del /Q build\*.*
del /Q %BLD_ID%.M51
del /Q %BLD_ID%.hex
del /Q %BLD_ID%.crc16
del /Q *.LST
del /Q *.build_log.htm
del /Q *.rvd
del /Q rvs_map.bin
del /Q rvs_map.rpz
del /Q rvs_map_compressed.bin
