////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 4
// Author           : T. J. Keen
// Date             : 13 June 2017
//
// Description      : Module hal.c provides an abstraction layer to the LCU's
//                    hardware with a set of functions that perform the low
//                    level manipulation of the IC's on the various circuit boards
//
////////////////////////////////////////////////////////////////////////////////

#include "hal.h"
#include "common_types.h"

#include "reg51atlprb2.h"   // special function register declarations for micro

#include "rvs.h"

////////////////////////////////////////////////////////////////////////////////
//
// Local defines
//
////////////////////////////////////////////////////////////////////////////////

#define PLD_COMPAT_SOFTWARE_NO_MSB               0x9AU     // software library Number 39595-E
#define PLD_COMPAT_SOFTWARE_NO_LSB               0xABU
#define PLD_COMPAT_INTERFACE_VERSION             0x01U

#define WARM_START_CHECK_PATTERN                   0XAAU


// MemoryPldSelect options
#define SELECT_FLASH_MEMORY                      0
#define SELECT_PLD                               1

// Parallel flash device commands
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_1       0xAAU
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_2       0x55U
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_3       0x80U
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_4       0xAAU
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_5       0x55U
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_6       0x30U

#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_1       0xAAAU
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_2       0x1555U
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_3       0xAAAU
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_4       0xAAAU
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_5       0x1555U

#define FLASH_COMMAND_CHIP_ERASE_CYCLE_1         0xAAU
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_2         0x55U
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_3         0x80U
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_4         0xAAU
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_5         0x55U
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_6         0x10U

#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_1         0xAAAU
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_2         0x1555U
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_3         0xAAAU
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_4         0xAAAU
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_5         0x1555U
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_6         0xAAAU

#define FLASH_COMMAND_RESET_CYCLE_1              0xF0U

#define FLASH_ADDRESS_RESET_CYCLE_1              0x00U

#define FLASH_COMMAND_WRITE_CYCLE_1              0xAAU
#define FLASH_COMMAND_WRITE_CYCLE_2              0x55U
#define FLASH_COMMAND_WRITE_CYCLE_3              0xA0U

#define FLASH_ADDRESS_WRITE_CYCLE_1              0xAAAU
#define FLASH_ADDRESS_WRITE_CYCLE_2              0x1555U
#define FLASH_ADDRESS_WRITE_CYCLE_3              0xAAAU



////////////////////////////////////////////////////////////////////////////////
//
// Global variables
//
////////////////////////////////////////////////////////////////////////////////

// These globals are needed to provide the serial comms interrupt with storage
// accessible by the main program loop and to facilitate status signalling to
// the main loop

// Linear command receive buffer
unsigned char xdata commandBuffer[COMMAND_BUFFER_SIZE] _at_ COMMAND_BUFFER_START;

unsigned char commandBufferPos;
bit commandAvailable;                       // command received from controller flag
static bit commandStart;

// Circular transmit buffer
static unsigned char xdata transmitBuffer[TRANSMIT_BUFFER_SIZE] _at_ TRANSMIT_BUFFER_START;

static unsigned char transmitBufferInPtr;
static unsigned char transmitBufferOutPtr;

static unsigned int transmitBufferCount;
bit uartTxActive;


////////////////////////////////////////////////////////////////////////////////
//
// Local function prototype declarations
//
////////////////////////////////////////////////////////////////////////////////

static unsigned char isDigit(char c);

////////////////////////////////////////////////////////////////////////////////
//
// Initialisation
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Initialses the micro-controller periphals
///
/// Function initialises the micro-controller's memory,
/// I2C bus, SPI bus, Timer 0 and 1

void HAL_MicroInit(void)
{
  // HAL_Init Micro memories
  AUXR |= 0x15;                             // A0 = 1 activate ALE only for external memory access
  // EXTRAM = 0 Allow access to internal XRAM
  // XRS = 5 Enable the maximum 2048 bytes of XRAM

  // HAL_Init I2C bus
  SSCON |= 0x42;                            // enable I2C, clock divider 192 for a bus frequency of 76.8 KHz (14.7456 MHz/192)

  // HAL_Init SPI bus

  // set up SPI in master mode with Fclk Periph/8 as baud rate
  // P1.5(MISO) serial input
  // P1.7(MOSI) serial output
  SPCON |= 0x10;                            // select master mode (MSTR bit)
  SPCON |= 0x02;                            // Fclk Periph/8 = 14.7456/8 = 1.8432 MHz (23LC1024 Fmax = 20 MHz)
  SPCON |= 0x20;                            // we are not using P1.1 so is available as standard I/O pin
  SPCON &= ~0x08;                           // CPOL=0 SCLK low when idle
  SPCON &= ~0x04;                           // CPHA=0
  SPCON |= 0x40;                            // enable spi (SPEN bit)

  // HAL_Init timer 0 for LED flashing (14.7456 MHz oscillator frequency, X2/6 cycles)
  // 16 bit rollover occurs after
  ET0 = 0;                                  // disable timer 0 interrupt
  TR0  = 0;                                 // stop timer 0
  TMOD &= ~0x0F;                            // clear timer 0 mode bits
  TMOD |= 0x01;                             // put timer 0 into 16-bit auto-reload no prescaler

  TL0 = 0;                                  // HAL_Init 16 bit counter low register to 0
  TH0 = 0;                                  // HAL_Init 16 bit counter high register to 0

  TR0 = 1;                                  // start timer 0

  // HAL_Init timer 1 for a HAL_Delay2ms counter
  ET1 = 0;                                  // disable timer 1 interrupt
  TR1 = 0;                                  // make sure timer 1 is stopped
  TMOD &= ~0xF0;                            // clear timer 1 mode bits
  TMOD |= 0x10;                             // put timer 1 into 16-bit auto-reload no prescaler

  EA = 1;                                   // enable all interrupts
}

////////////////////////////////////////////////////////////////////////////////
//
// UART
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Initialses UART for requested baud rate
//
/// Initialses the UART for the requested baud rate
/// @ 14.7456 MHz oscillator frequency
///
/// \note that clock doubling is enabled
///
/// \param baud The baud rate for the UART
/// uses the global variables commandAvailable, transmitBufferInPtr,
/// transmitBufferOutPtr,transmitBufferCount and uartTxActive


void HAL_UartInit(unsigned char baud)
{
  unsigned char code Divisor[] = {0xA0,0xD0,0xE8,0xF0,0xF8}; // 9600,19200,38400,57600,115200

  REN =0;                                         // disable serial reception

  RCAP2L = Divisor[baud];                         // load divisor for required baud rate
  RCAP2H = 0xFF;

  T2CON = 0x34;                                   // Set TX and Rx clocks to use timer 2
  SCON  = 0x52;                                   // variable baud rate 8 bit uart,rx enabled,RI=0,TI=0

  // Initialise linear command buffer control registers
  commandStart = FALSE;
  commandAvailable = FALSE;

  // Initialise circular transmit buffer control variables
  transmitBufferInPtr  = 0;
  transmitBufferOutPtr = 0;
  transmitBufferCount = 0;
  uartTxActive = FALSE;

  ES=1;                                           // serial interrupt on
  REN=1;                                          // enable serial reception
}

/// \brief Reads ASCII pair from command buffer
///
/// Function to read a pair of characters from the
/// command buffer and convert them from a hexidecimal
/// representation to an unsigned 8-bit integer.
/// uses the global variable commandBuffer
///
/// \param position Position of character pair in
///        command buffer
///
/// \return decimal value of hex pair

unsigned char HAL_UartGetHexPair(unsigned char position)
{
  unsigned char index;
  unsigned char digit1;
  unsigned char digit2;

  index = (position - 1)*2;                     // index to the start of the requested pair

  digit1 = commandBuffer[index];                // first character

  if (isDigit(digit1) == TRUE)
  {
    digit1 = digit1 - 48;
  }
  else
  {
    digit1 = digit1 - 55;
  }

  digit2 = commandBuffer[index + 1];            //  second character

  if (isDigit(digit2) == TRUE)
  {
    digit2 = digit2 - 48;
  }
  else
  {
    digit2 = digit2 - 55;
  }

  return (digit1*16 + digit2);
}

/// \brief Places the passed character on UART transmit buffer
///
/// \param ch Character to place on UART transmit buffer
/// uses the global variables transmitBuffer,transmitBufferInPtr, transmitBufferCount

void HAL_UartPutChar(char ch)
{
  ES = 0;                                   // disable serial interrupt

  // Enqueue character to circular transmit buffer
  transmitBuffer[transmitBufferInPtr++] = ch;
  transmitBufferCount++;

  if (transmitBufferInPtr > (TRANSMIT_BUFFER_SIZE - 1))
  {
    transmitBufferInPtr = 0;
  }

  if (!uartTxActive)
  {
    TI = 1;
    uartTxActive = TRUE;
  }

  ES = 1;
}

/// \brief Output an integer as a hex string
///
/// Output an integer as a hex string over the serial
/// port.
///
/// \param number Number to output as hex
/// \param numDigits Number of hex digits to output

void HAL_UartPrintHex(long number, unsigned char numDigits)
{
  unsigned char i;
  code char hexChar[] = {'0','1','2','3','4','5','6','7',
                         '8','9','A','B','C','D','E','F'};
  char hex[6];

  if (numDigits > 6)                                // trap for too many digits specified
  {
    numDigits = 6;
  }

  for (i = 0; i < numDigits ; i++)
  {
    hex[numDigits - 1 - i] = hexChar[number & 0xF];
    number >>= 4;
  }

  for (i = 0; i < numDigits; i++)
  {
    HAL_UartPutChar(hex[i]);
  }
}

/// \brief Writes command parameters to flash
///
/// A string of up to 50 ascii hexpairs is converted to 50 binary encoded bytes and written to flash
/// uses the global variable commandBuffer
///
///
/// \param address The start address in flash to write the data bytes to.

unsigned char HAL_UartWriteCommandBufferToFlash(unsigned long address)
{
  unsigned char i;
  unsigned char bytesWritten;
  unsigned char hexPairCount;
  unsigned char byteToWrite;

  bytesWritten = 0;

  i = 0;

  while (commandBuffer[i] != '\r')                      // count the number of received characters in the line buffer
  {
    i++;
  }

  hexPairCount = i/2;

  if (i%2 == 0)
  {
    for(i = 1; i < hexPairCount; i++)
    {
      byteToWrite = HAL_UartGetHexPair(i + 1);

      if (HAL_FlashWriteAndVerify(address + (unsigned long)i - 1, byteToWrite) != SUCCESS)
      {
        bytesWritten = 0;
        break;
      }

      bytesWritten++;
    }
  }

  return bytesWritten;
}

/// \brief The UART interrupt service routine
///
/// The UART interrupt service routine. Transmits
/// any characters in circular transmit buffer.
/// Receives any characters into the linear command
/// buffer. The commandAvailable flag is set if the
/// command buffer contains a full command.
/// uses the global variables commandBuffer, commandAvailable,
/// transmitBuffer, transmitBufferOutPtr, transmitBufferCount, uartTxActive and commandBufferPos

void HAL_UartServicePort(void) interrupt 4
{
  char ch;

  if (TI)                                                     // if the transmit buffer is empty
  {
    TI = 0;

    if (transmitBufferCount > 0)                              // if there are one or more characters in the circular tx buffer
    {
      ch = transmitBuffer[transmitBufferOutPtr++];            // get character at output buffer pointer
      SBUF = ch;                                              // load character from buffer to uart transmit buffer
      transmitBufferCount--;                                  // decrement the buffer character count

      if (transmitBufferOutPtr > (TRANSMIT_BUFFER_SIZE - 1))  // if the pointer has reached the buffer end
      {
        transmitBufferOutPtr = 0;                             // then reset it to the beginning of the buffer
      }
    }
    else
    {
      uartTxActive = FALSE;                                   // flag that we are no longer outputing characters
    }
  }

  if (RI)                                                     // is this a receive character interrupt?
  {
    ch = SBUF;                                                // get receive character
    HAL_UartPutChar(ch);                                      // echo character

    if (ch == '!')                                            // is it the start command character?
    {
      commandStart = TRUE;                                    // flag start of command
      commandBufferPos = 0;                                   // reset write pointer to start of command buffer
    }
    else
    {
      if (commandStart)
      {
        if (ch == '\r')
        {
          commandBuffer[commandBufferPos] = '\r';
          commandAvailable = TRUE;
          commandStart = FALSE;
        }
        else
        {
          if (commandBufferPos < COMMAND_BUFFER_SIZE)       // if we have not gone past buffer end
          {
            commandBuffer[commandBufferPos] = ch;           // write character to command line buffer
            commandBufferPos++;
          }
        }
      }
    }

    RI = 0;
  }
}

/// \brief flushes the command buffer
///
/// Function to write the Null character (0x00) to
/// every location in the receive line buffer buffer.
/// uses the global variable commandBuffer

void HAL_FlushCommandBuffer(void)
{
  unsigned char index;

  for (index = 0; index < COMMAND_BUFFER_SIZE; index++)
  {
    commandBuffer[index]= 0;
  }

}
/// \brief returns the number of arguments of a command in the line buffer
///
/// Function returns the number of arguments found or 0 if there is an incomplete hex pair

unsigned char HAL_CommandBufferNumberOfArgs(void)
{
  unsigned char numberOfArgs;
  unsigned char index;

  numberOfArgs = 0;

  for (index = 0; index < COMMAND_BUFFER_SIZE; index++)
  {
    if (commandBuffer[index]== '\r')
    {
      break;
    }
  }

  if  (index%2 == 0)                      // check for an even number of characters received
  {
    numberOfArgs = (index/2)-1;           // subtract 1 for the command code
  }

  return numberOfArgs;
}

////////////////////////////////////////////////////////////////////////////////
//
// PLD register access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Writes a byte to a PLD register
///
/// Function to write a byte to the PLD register
/// mapped to the specified address in memory.
///
/// \param address Memory-mapped address of register
/// \param value Byte value to write to PLD register

void HAL_PldWriteLatch(unsigned int address, unsigned char value)
{
  unsigned char xdata * data memPointer; // ptr in data to xdata unsigned char

  MemoryPldSelect = SELECT_PLD;          // select CPLD 8 bit Registers for addressing

  memPointer = (unsigned char xdata*)address;
  *memPointer = value;
}

/// \brief Reads a byte from a PLD register
///
/// Function to read a byte from the PLD register
/// mapped to the specified address in memory.
///
/// \param address Memory-mapped address of register
///
/// \return byte value read from PLD register

unsigned char HAL_PldReadLatch(unsigned int address)
{
  unsigned char xdata * data memPointer;
  unsigned char value;

  MemoryPldSelect = SELECT_PLD;

  memPointer = (unsigned char xdata*)address;
  value = *memPointer;

  return value;
}

/// \brief Sets the specified bit(s) to the PLD register
///
/// Function to set a specific bit(s) within one of the PLD's
/// registers whilst preserving the value of the remaining
/// bits within the register. This function first reads the
/// PLD register, applies the bit mask and then writes the
/// resulting value back to the PLD.
///
/// \param address Memory-mapped address of register
/// \param mask of bits to set in register

void HAL_PldLatchSetBitMask(unsigned int address, unsigned char mask)
{
  unsigned char registerValue;

  registerValue = HAL_PldReadLatch(address);

  registerValue |= mask;

  HAL_PldWriteLatch(address, registerValue);
}

/// \brief Clears the specified bit(s) to the PLD register
///
/// Function to clear specific bit(s) within one of the PLD's
/// registers whilst preserving the value of the remaining
/// bits within the register. This function first reads the
/// PLD register, applies the bit mask and then writes the
/// resulting value back to the PLD.
///
/// \param address Memory-mapped address of register
/// \param mask of bits to clear in register
///
/// \return byte value read from PLD register

void HAL_PldLatchClearBitMask(unsigned int address, unsigned char mask)
{
  unsigned char registerValue;

  registerValue = HAL_PldReadLatch(address);

  registerValue &= ~mask;

  HAL_PldWriteLatch(address, registerValue);
}

/// \brief Determines whether PLD is compatible with software
///
/// Function reads the PLD part number an interface version
/// number to determine if the software is compatible with
/// the PLD.
///
/// \return Returns 1 if compatible, 0 if not

unsigned char HAL_PldIsCompatible(void)
{
  unsigned char isCompatible;
  unsigned char registerValue;

  isCompatible = TRUE;

  // Check firmware part number compatibility
  registerValue = HAL_PldReadLatch(PLD_REG_SOFTWARE_NO_MSB);

  if (registerValue != PLD_COMPAT_SOFTWARE_NO_MSB)
  {
    isCompatible = FALSE;
  }

  registerValue = HAL_PldReadLatch(PLD_REG_SOFTWARE_NO_LSB);

  if (registerValue != PLD_COMPAT_SOFTWARE_NO_LSB)
  {
    isCompatible = FALSE;
  }

  // Check firmware interface compatibility
  registerValue = HAL_PldReadLatch(PLD_REG_INTERFACE_VERSION);

  if (registerValue != PLD_COMPAT_INTERFACE_VERSION)
  {
    isCompatible = FALSE;
  }

  return isCompatible;
}

/// \brief Asserts Radio BIT line on J1
///
/// Function to assert the Radio BIT line on J1.
/// This allow indicates to the PLD that the
/// software failed PBIT.

void HAL_AssertRadioBit(void)
{
  HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_PBIT_FAIL);
}

/// \brief Hands control over to PLD
///
/// Function to set PLD as the master device
/// over the micro-controller for normal LCU
/// operation

void HAL_PldSetAsMaster(void)
{
  HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_CPLD_MODE);
}

/// \brief Checks if Factory Test Mode is selected
///
/// Function detects whether the Factory Test Mode
/// has been selected i.e. all Radio Select (RSEL)
/// lines on the J1 connector are grounded
///
/// \return 1 if Factory Test selected, 0 if not

unsigned char HAL_FactoryTestSelected(void)
{
  unsigned char registerValue;
  unsigned char result;

  registerValue = HAL_PldReadLatch(PLD_REG_CPLD_RADIO);

  registerValue &= PLD_CPLD_RADIO_RSEL;

  if (registerValue == 0)
  {
    result = TRUE;
  }
  else
  {
    result = FALSE;
  }

  return result;
}

/// \brief Checks if the LCU powered-up warm or cold
///
/// Function detects whether the LCU powered-up from
/// warm (brown-out) or cold. It looks for the check
/// pattern 0xAA in the PLD POWER_UP register.
///
/// \return 1 for a warm start, 0 for a cold start

unsigned char HAL_WarmStartDetected(void)
{
  unsigned char registerValue;
  unsigned char result;

  registerValue = HAL_PldReadLatch(PLD_REG_POWER_UP);

  if (registerValue == WARM_START_CHECK_PATTERN)
  {
    result = TRUE;
#pragma RVS instrumentation_point;

#pragma RVS add_statement("HAL_UartInit(0X00U)")
#pragma RVS add_statement("HAL_PldLatchSetBitMask(0x8001U, 0x80U)")
#pragma RVS add_statement("RVS_Output()")    
  }
  else
  {
    result = FALSE;
  }

  return result;
}

/// \brief Sets flag in PLD to indicate a warm-start
///        if a brown-out were to occur
///
/// Functions sets the contents of the PLD POWER-UP
/// register to the "Check Pattern" used by the
/// LCU software on start-up to determine if a
/// cold-start or warm-start occurred.

void HAL_SetWarmStartFlag(void)
{
  HAL_PldWriteLatch(PLD_REG_POWER_UP, WARM_START_CHECK_PATTERN);
}

////////////////////////////////////////////////////////////////////////////////
//
// External parallel flash device access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Erases all contents of external flash device
///
/// \return status of erase operation, 0 for success,
///         1 for failure (timeout error)

unsigned char HAL_FlashEraseChip()
{
  unsigned char xdata * data memPointer; // ptr in data to xdata unsigned char
  unsigned char status;

  EA = 0;                              // disable interrupts

  AUXR |= 0x02;                        // set EXTRAM bit to access full external memory space

  MemoryPldSelect = SELECT_PLD;

  memPointer = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
  *memPointer = 0x00;

  MemoryPldSelect = SELECT_FLASH_MEMORY;

  memPointer =  (unsigned char xdata*)FLASH_ADDRESS_CHIP_ERASE_CYCLE_1;
  *memPointer = FLASH_COMMAND_CHIP_ERASE_CYCLE_1;

  memPointer  = (unsigned char xdata*)FLASH_ADDRESS_CHIP_ERASE_CYCLE_2;
  *memPointer = FLASH_COMMAND_CHIP_ERASE_CYCLE_2;

  memPointer  = (unsigned char xdata*)FLASH_ADDRESS_CHIP_ERASE_CYCLE_3;
  *memPointer = FLASH_COMMAND_CHIP_ERASE_CYCLE_3;

  memPointer  = (unsigned char xdata*)FLASH_ADDRESS_CHIP_ERASE_CYCLE_4;
  *memPointer = FLASH_COMMAND_CHIP_ERASE_CYCLE_4;

  memPointer  = (unsigned char xdata*)FLASH_ADDRESS_CHIP_ERASE_CYCLE_5;
  *memPointer = FLASH_COMMAND_CHIP_ERASE_CYCLE_5;

  memPointer  = (unsigned char xdata*)FLASH_ADDRESS_CHIP_ERASE_CYCLE_6;
  *memPointer = FLASH_COMMAND_CHIP_ERASE_CYCLE_6;

  status = HAL_FlashReadyWait(0,0);

  AUXR &= ~0x02;                       // clear EXTRAM bit to allow access to 2K XRAM
  EA = 1;                              // re-enable interrupts
  return status;
}

/// \brief Write a byte to the external flash device
///
/// Writes a byte to the specified address in the
/// external Flash device. The status of write
/// operation is returned by the function
///
/// \note A timeout error may be cause by the location
///       not having been erased
///
/// \param address Address to write to on flash device
/// \param value Byte value to write to flash
///
/// \return status of write operation, 0 for success,
///         1 for failure (timeout error)

unsigned char HAL_FlashWrite(unsigned long address,unsigned char value)
{
  unsigned char xdata * data memPointer; // ptr in data to xdata unsigned char
  unsigned char sector;
  unsigned int shortAddress;
  unsigned char status = FAIL;

  if (address <= FLASH_LAST_ADDRESS)           // check that address is in range
  {
    EA = 0;                                    // disable interrupts

    AUXR |= 0x02;                              // set EXTRAM bit to access full external memory space

    shortAddress = (unsigned int)(address & 0xFFFF);
    sector      = (unsigned char)(address >> 16);

    MemoryPldSelect = SELECT_PLD;

    memPointer = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
    *memPointer = 0x00;                        // for address 0

    MemoryPldSelect = SELECT_FLASH_MEMORY;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_WRITE_CYCLE_1;
    *memPointer = FLASH_COMMAND_WRITE_CYCLE_1;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_WRITE_CYCLE_2;
    *memPointer = FLASH_COMMAND_WRITE_CYCLE_2;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_WRITE_CYCLE_3;
    *memPointer = FLASH_COMMAND_WRITE_CYCLE_3;

    MemoryPldSelect = SELECT_PLD;

    memPointer = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
    *memPointer = sector;

    MemoryPldSelect = SELECT_FLASH_MEMORY;

    memPointer = (unsigned char xdata*)shortAddress;
    *memPointer = value;

    status = HAL_FlashReadyWait(sector, shortAddress);

    AUXR &= ~0x02;                              // clear EXTRAM bit to allow access to 2K XRAM
    EA = 1;                                     // re-enable interrupts
  }

  return status;
}

unsigned char HAL_FlashWriteAndVerify(unsigned long address, unsigned char WriteByte)
{
  unsigned char readByte;
  unsigned char status;

  status = HAL_FlashWrite(address, WriteByte);

  if    (status == SUCCESS)
  {
    readByte = HAL_FlashRead(address);          // read it back for verification

    if (readByte != WriteByte)                  // check written correctly
    {
      status = FAIL;                            // fail if not
    }
  }

  return status;
}

/// \brief read a byte from the external flash device
///
/// Reads a byte from the specified address in the
/// exxternal Flash device.
///
/// \param address Address to read from on flash device
///
/// \return byte value read from flash

unsigned char HAL_FlashRead(unsigned long address)
{
  unsigned char xdata * data memPointer;
  unsigned char sector;
  unsigned char value;
  unsigned int  shortAddress;

  EA = 0;                                      // disable interrupts

  AUXR |= 0x02;                                // set EXTRAM bit to access full external memory space

  shortAddress = address & 0XFFFF;
  sector =  address >> 16;

  MemoryPldSelect = SELECT_PLD;

  memPointer = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
  *memPointer = sector;

  MemoryPldSelect = SELECT_FLASH_MEMORY;

  memPointer = (unsigned char xdata*)shortAddress;
  value = *memPointer;

  AUXR &= ~0x02;                               // clear EXTRAM bit to allow access to XRAM

  EA = 1;                                      // re-enable interrupts

  return value;
}

/// \brief Waits until the external flash device is ready
///
/// Function waits while flash chip is busy, for example,
/// after an erase operation.
///
/// \param sector used by operation to wait on
/// \param address used by operation to wait on
///
/// \return Returns 1 if ready, otherwise 0

unsigned char HAL_FlashReadyWait(unsigned char sector, unsigned int shortAddress)
{
  unsigned char xdata * data memPointer;  // ptr in data to xdata unsigned char
  unsigned char status;

  EA = 0;                                      // disable interrupts

  AUXR |= 0x02;                                // set EXTRAM bit to access full external memory space

  status = SUCCESS;

  MemoryPldSelect = SELECT_PLD;

  memPointer = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
  *memPointer = sector;

  MemoryPldSelect = SELECT_FLASH_MEMORY;

  memPointer = (unsigned char xdata*)shortAddress;

  while (nFlashBusy == 0)                      // wait for busy line to go high
  {
    if ((*memPointer & FLASH_DQ5) > 0)         // if DQ5 goes high then FLASH has exceeded its timing limits
    {
      if (nFlashBusy == 0)                     // as we are asynchronously reading the busy line check that busy is still low as DQ5 status is only valid with busy = 0
      {
        status = FAIL;                         // As DQ5 has flagged an operation timeout failure
        HAL_FlashReset();                      // Need to reset the FLASH memory  - after this reset the busy line returns to high
        break;
      }
    }
  }

  AUXR &= ~0x02;                               // clear EXTRAM bit to allow access to 2K XRAM

  EA = 1;                                      // re-enable interrupts

  return status;
}

/// \brief Reset the external flash device

void HAL_FlashReset(void)
{
  unsigned char xdata * data memPointer;      // ptr in data to xdata unsigned char

  EA = 0;                                     // disable interrupts

  AUXR |= 0x02;                               // set EXTRAM bit to access full external memory space

  MemoryPldSelect = SELECT_PLD;

  memPointer  = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
  *memPointer = 0x00;

  MemoryPldSelect = SELECT_FLASH_MEMORY;

  memPointer  = (unsigned char xdata*)FLASH_COMMAND_RESET_CYCLE_1;
  *memPointer = FLASH_COMMAND_RESET_CYCLE_1;

  AUXR &= ~0x02;                              // clear EXTRAM bit to allow access to 2K XRAM

  EA = 1;                                     // re-enable interrupts
}

/// \brief Erases the specified sector in the external flash device
///
/// \param sector The sector in flash to erase

unsigned char HAL_FlashEraseSector(unsigned char sector)
{
  unsigned char xdata * data memPointer;                                   // ptr in data to xdata unsigned char
  unsigned char sectorLatchData;
  unsigned int  shortAddress;

  unsigned char status = FAIL;

  if (sector <= FLASH_SECTOR_141)                                          // if sector is within range
  {
    EA = 0;                                                                // disable interrupts

    AUXR |= 0x02;                                                          // set EXTRAM bit to access full external memory space

    if (sector <= FLASH_SECTOR_7)                                          // Eight off 8 kbyte sectors SA0-SA7
    {
      sectorLatchData = 0;
      shortAddress = sector << 13;                                         // LSB align with FLASH address bit A12
    }                                                                      // (shift 13 not 12 because micro A0 = FLASH A-1 in byte mode)
    else if ((sector >= FLASH_SECTOR_8) && (sector <= FLASH_SECTOR_133))   // 126 off 64 kbyte sectors SA8-SA133
    {
      sectorLatchData = sector - FLASH_SECTOR_7;
      shortAddress = 0;
    }
    else if ((sector >= FLASH_SECTOR_134) && (sector <= FLASH_SECTOR_141)) // Eight off 8 kbyte sectors SA134-SA141
    {
      sectorLatchData = 0x7F;                                              // LSB align with FLASH address bit A12
      shortAddress = (sector - FLASH_SECTOR_134) << 13;                    // Shift 13 not 12 because micro A0 = FLASH A-1 in byte mode
    }

    MemoryPldSelect = SELECT_PLD;

    memPointer  = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
    *memPointer = 0x00;                                                    // for address 0

    MemoryPldSelect = SELECT_FLASH_MEMORY;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_SECTOR_ERASE_CYCLE_1;
    *memPointer = FLASH_COMMAND_SECTOR_ERASE_CYCLE_1;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_SECTOR_ERASE_CYCLE_2;
    *memPointer = FLASH_COMMAND_SECTOR_ERASE_CYCLE_2;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_SECTOR_ERASE_CYCLE_3;
    *memPointer = FLASH_COMMAND_SECTOR_ERASE_CYCLE_3;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_SECTOR_ERASE_CYCLE_4;
    *memPointer = FLASH_COMMAND_SECTOR_ERASE_CYCLE_4;

    memPointer  = (unsigned char xdata*)FLASH_ADDRESS_SECTOR_ERASE_CYCLE_5;
    *memPointer = FLASH_COMMAND_SECTOR_ERASE_CYCLE_5;

    MemoryPldSelect = SELECT_PLD;

    memPointer  = (unsigned char xdata*)PLD_REG_SECTOR_LATCH;
    *memPointer = sectorLatchData;                                        // write to sector latch

    MemoryPldSelect = SELECT_FLASH_MEMORY;

    memPointer  = (unsigned char xdata*)shortAddress;
    *memPointer = FLASH_COMMAND_SECTOR_ERASE_CYCLE_6;

    // the sector erase timeout timer (a 50uS timer within the FLASH device) now starts
    // wait for the sector to erase, HAL_FlashReadyWait is passed the sector address of the sector being erased
    status = HAL_FlashReadyWait(sectorLatchData, shortAddress);

    AUXR &= ~0x02;                                                        // clear EXTRAM bit to allow access to 2K XRAM

    EA = 1;                                                               // re-enable interrupts
  }
  return status;
}

////////////////////////////////////////////////////////////////////////////////
//
// 128Kbyte RAM SPI device access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Writes a byte to the 23LC1024 128Kbyte SPI RAM chip
///
/// Function to read a byte from the 23LC1024 128Kbyte SPI RAM chip
/// at the address specified by the passed high/mid/low address
/// parameters. The valid address range of the chip is 0x0-0x1FFFF.
///
/// \param addressHighByte Bits A23-A16 of address to read from
///        (bit A18-A23 are not used)
/// \param addressMidByte  Bits A15-A8  of address to read from
/// \param addressLowhByte Bits A7-A0   of address to read from
///
/// \return byte value read from RAM chip

void HAL_RamWrite(unsigned char addressHighByte, unsigned char addressMidByte,
                  unsigned char addressLowByte, unsigned char value)
{
  RamCS = 0;                                        // chip select pin low
  HAL_SpiTransfer(SPI_WRITE);
  HAL_SpiTransfer(addressHighByte);
  HAL_SpiTransfer(addressMidByte);
  HAL_SpiTransfer(addressLowByte);
  HAL_SpiTransfer(value);
  RamCS = 1;                                        // chip select high
}

/// \brief Reads a byte from the 23LC1024 128Kbyte SPI RAM chip
///
/// Function to read a byte from the 23LC1024 128Kbyte SPI RAM chip
/// at the address specified by the passed high/mid/low address
/// parameters. The valid address range of the chip is 0x0-0x1FFFF.
///
/// \param addressHighByte Bits A23-A16 of address to read from
///        (bit A18-A23 are not used)
/// \param addressMidByte  Bits A15-A8  of address to read from
/// \param addressLowhByte Bits A7-A0   of address to read from
///
/// \return byte value read from RAM chip

unsigned char HAL_RamRead(unsigned char addressHighByte,
                          unsigned char addressMidByte,
                          unsigned char addressLowByte)
{
  unsigned char value;

  RamCS = 0;                            // chip select pin low
  HAL_SpiTransfer(SPI_READ);
  HAL_SpiTransfer(addressHighByte);
  HAL_SpiTransfer(addressMidByte);
  HAL_SpiTransfer(addressLowByte);
  value = HAL_SpiTransfer(0);           // 0 is dummy data
  RamCS = 1;                            // chip select high

  return value;
}

////////////////////////////////////////////////////////////////////////////////
//
// SPI bus access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Transmits and receives a byte over SPI bus
///
/// \param txValue Byte value to transmit over SPI bus
///
/// \return byte value read over SPI bus

unsigned char HAL_SpiTransfer(unsigned char txValue)
{
  unsigned char rxValue;

  SPDAT = txValue;

  while ((SPSTA & SPIF_BIT) == 0)               // wait for SPIF the SPI transfer complete flag to be set
  {
    // Do nothing
  }

  rxValue = SPDAT;

  return rxValue;
}

////////////////////////////////////////////////////////////////////////////////
//
// I2C bus access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Writes a byte to the I2C bus
///
/// \param value Byte value to write to I2C bus

void HAL_I2cWriteByte(unsigned char value)
{
  SSDAT = value;
  SSCON &= ~INT_FLAG;                       // clear the SI flag to initiate sending of the data
  while ( (SSCON & INT_FLAG) == 0 )         // wait for SI flag to be set
  {
    // Do nothing
  }
}

/// \brief Reads a byte from the I2C bus
///
/// Reads a byte from the I2C bus. Optionally, an acknowledge
/// can be specified.
///
/// \param assertAck Asserts an acknowledge if set to 1
///
/// \return value read from I2C

unsigned char HAL_I2cReadByte(unsigned char assertAck)
{
  unsigned char value;

  if (assertAck == I2C_NACK)
  {
    SSCON &= ~ASSERT_ACK_FLAG;          // clear the AA flag to send a NAK in response to the received data byte
  }

  SSCON &= ~INT_FLAG;                   // clear the SI flag to initiate reception of the data byte

  while ( (SSCON & INT_FLAG) == 0)      // wait for SI flag to be set
  {
    // Do nothing
  }

  value = SSDAT;                        // get the received data

  return value;
}

/// \brief initiate an I2C bus start condition

void HAL_I2cStart(void)
{
  SSCON |= START_FLAG;
  while ((SSCON & INT_FLAG) == 0)   // wait for SI flag to be set
  {
    // Do nothing
  }

  SSCON &= ~START_FLAG;             // must clear the start flag
}

/// \brief initiate an I2C bus repeated start condition

void HAL_I2cRepeatStart(void)
{
  SSCON |= START_FLAG;
  SSCON &= ~INT_FLAG;              // clear the SI flag to initiate sending of the start condition
  while ((SSCON & INT_FLAG) == 0)  // wait for SI flag to be set
  {
    // Do nothing
  }
  SSCON &= ~START_FLAG;            // must clear the start flag
}

/// \brief Initiate an I2C bus Stop condition

void HAL_I2cStop()
{
  SSCON |= STOP_FLAG;
  SSCON &= ~INT_FLAG;   // clear the SI flag to initiate sending of the STOP condition
}

////////////////////////////////////////////////////////////////////////////////
//
// Elapsed time indicator access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Writes a byte to the specified ETI chip register
///
/// Function to write to the DS1682 Total-Elapsed-Time Recorder
/// IC's register specified by the address parameter over the I2C bus.
///
/// \param address Address of the ETI chip register
/// \param value Byte value to write to ETI chip

void HAL_EtiWriteReg(unsigned char address,unsigned char value)
{
  HAL_I2cStart();
  HAL_I2cWriteByte(I2C_ETI_ADDRESS);
  HAL_I2cWriteByte(address);
  HAL_I2cWriteByte(value);
  HAL_I2cStop();
}

/// \brief Reads a byte from the specified ETI chip register
///
/// Function to read from the DS1682 Total-Elapsed-Time Recorder
/// IC's register  specified by the address parameter over the I2C bus.
///
/// \param address Address of the ETI chip register
///
/// \return contents of ETI register

unsigned char HAL_EtiReadReg(unsigned char address)
{
  unsigned char value;

  HAL_I2cStart();
  HAL_I2cWriteByte(I2C_ETI_ADDRESS);
  HAL_I2cWriteByte(address);
  HAL_I2cRepeatStart();
  HAL_I2cWriteByte(I2C_ETI_ADDRESS | I2C_READ);
  value = HAL_I2cReadByte(I2C_NACK);
  HAL_I2cStop();

  return value;
}

////////////////////////////////////////////////////////////////////////////////
//
// Bus expander access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Writes a byte to the PCF8574 Port expander
///
/// Function to write to a byte to the PCF8574 Port expander
/// over the I2C bus.
///
/// \param value Byte value to write to PCF8574 Port expander

void HAL_BusExpanderWrite(unsigned char value)
{
  HAL_I2cStart();
  HAL_I2cWriteByte(I2C_EXPANDER_ADDRESS);
  HAL_I2cWriteByte(value);
  HAL_I2cStop();
}

////////////////////////////////////////////////////////////////////////////////
//
// LED access
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Control the Input LED
///
/// Function to turn the Input LED on & off.
///
/// \param on Turns LED on if '1', otherwise turn LED off

void HAL_SetInputLed(unsigned char state)
{
  if (state == ON)
  {
    HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_PSU_LED);
  }
  else if (state == OFF)
  {
    HAL_PldLatchClearBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_PSU_LED);
  }
}

/// \brief Control the Output LED
///
/// Function to turn the Output LED on & off.
///
/// \param on Turns LED on if '1', otherwise turn LED off

void HAL_SetOutputLed(unsigned char state)
{
  if (state == ON)
  {
    HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_MICRO_LED);
  }
  else if (state == OFF)
  {
    HAL_PldLatchClearBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_MICRO_LED);
  }
}

/// \brief Control the PCB diagnostic LED
///
/// Function to turn the PCB diagnostic LED on & off.
///
/// \param on Turns LED on if '1', otherwise turn LED off

void HAL_SetPcbLed(unsigned char state)
{
  if (state == ON)
  {
    HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_CPLD_LED);
  }
  else if (state == OFF)
  {
    HAL_PldLatchClearBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_CPLD_LED);
  }
}

/// \brief Flashes Input LED at a rate of 2 Hz
///
/// Function to flash input LED to notify user of Factory
/// Test Locked state. It uses the overflow flag from the
/// free running 16 bit Timer 0 to provide a timer tick.
/// function must be continuosly called in a loop to function
/// correctly.

void HAL_FlashInputLed(unsigned char enabled)
{
  static unsigned char count = 0;
  static unsigned char toggle = 0;

  if (TF0 && enabled)               // The timer 1 overflow flag is set every 26ms
  {
    TR0 = 0;                        // stop timer 1 counting
    TF0 = 0;                        // clear the overflow flag
    TR0 = 1;                        // re-start timer 1 counting

    if (count++ > 11)
    {
      count = 0;
      toggle = !toggle;
    }

    if (toggle)
    {
      HAL_SetInputLed(ON);
    }
    else
    {
      HAL_SetInputLed(OFF);
    }
  }
}

/// \brief Waits for 2ms
///
/// function waits for 2ms using Timer 1.
/// Timer 1 in compatibility and X2 modes counts at
/// 1/6 of the oscillator frequency  :
///   14.7456 MHz/6 = 2.4576 MHz
///   1 / 2.4576 MHz = 0.406uS tick
///   2ms /0.406uS ticks = 4915
///   65535 - 4915 = 60620 = 0xECCC

void HAL_Delay2ms(void)
{
  TR1 = 0;                  // stop timer 1 counting

  TH1 = 0xEC;               // set the timer 1 counters
  TL1 = 0xCC;

  TF1 = 0;                  // clear the overflow flag
  TR1 = 1;                  // start timer 1 counting

  while (!TF1)
  {
    // No operation
  }

  TR1 = 0;                  // stop timer 1 counting
}

/// \brief function to wait for the PLD to initialise
///
// The CPLD has a delayed initialisation due to the 1.8V core voltages slow rise time because of the brown-out hold-up capacitance charging
// The CPLD sets the "CpldReady" line low to notify the microcontroller that it has loaded its image and initialised itself.
// All pins of the CPLD default to input with weak pull-up when the device is unprogrammed (so signalling "not ready")
//
// A timeout of 2 seconds is allowed before the code halts and routes the JTAG chain to J1
// This is done in order that a unit can be recovered if the CPLD programming fails after device erasure

void HAL_PldWaitForReady(void)
{
  int count;

  count = 0;                  // initialise counter

  while (CpldReady == 1)      // while the CPLD output is in the power-up state of input with pull-up
  {
    HAL_Delay2ms();           // 2ms delay

    if (count++ > 1000)       // if 2 second has been exceeded
    {
      HAL_BusExpanderWrite(JTAG_SOURCE_J1);    // Route JTAG to J1

      #pragma RVS instrumentation_point;
      #pragma RVS add_statement("HAL_UartInit(0X00U)")
      #pragma RVS add_statement("RVS_Output()")

      while (1)               // loop forever
      {}
    }
  }
}

/// \brief Returns the Working Antenna Table number
///
/// function to detemine the Working Antenna Table number as
/// specified by the state of the J1 connector Antenna
/// Select (ASEL) lines:
///
/// Pin J1,K (ASEL1)    Pin J1,J (ASEL0)    Antenna No.     Function Returns
/// OPEN              OPEN                1               0
/// OPEN              GND                 2               1
/// GND               OPEN                3               2
/// GND               GND                 4               3
///
/// \return Number of drive lines {7, 8, 9} or 0 if invalid

unsigned char HAL_GetWorkingAntennaTable(void)
{
  unsigned char antennaSelects;

  antennaSelects = HAL_PldReadLatch(PLD_REG_CPLD_RADIO);
  antennaSelects =  ~antennaSelects;                            // invert bits as GND = 1 and OPEN = 0
  antennaSelects &= PLD_CPLD_RADIO_ASEL;
  antennaSelects >>= 3;

  return antennaSelects;
}

/// \brief Returns the number of antenna drive lines
///
/// function to detemine the number of antenna drive lines
/// used by a working antenna table. This will be 7, 8 or 9
/// lines, the function returns 0 if the number of antenna
/// drive lines is invalid.
///
/// \return Number of drive lines {7, 8, 9} or 0 if invalid

unsigned char HAL_GetNumAntennaLines(void)
{
  unsigned char numberOfLines;
  unsigned char linesRegisterValue;

  linesRegisterValue = HAL_PldReadLatch(PLD_REG_CPLD_RADIO);
  linesRegisterValue &= PLD_CPLD_RADIO_LINES;
  linesRegisterValue >>= 5;

  switch (linesRegisterValue)
  {
  case 0:
    numberOfLines = 7;
    break;
  case 1:
    numberOfLines = 8;
    break;
  case 2:
    numberOfLines = 9;
    break;
  case 3:
    numberOfLines = 0;
    break;
  default:
    numberOfLines = 0;
  }

  return numberOfLines;
}

////////////////////////////////////////////////////////////////////////////////
//
// Local utility functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Checks whether char is a digit (0-9)
///
/// Function to identify if an ASCII character is a digit (0-9)
///
/// \param c Character to check
///
/// \return Returns 1 if 'c' is digit, otherwise 0

static unsigned char isDigit(char c)
{
  unsigned char result;

  if ((c >= '0') && (c <='9'))
  {
    result = TRUE;
  }
  else
  {
    result = FALSE;
  }

  return result;
}
