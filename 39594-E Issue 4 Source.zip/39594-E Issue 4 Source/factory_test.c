////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 4
// Author           : T. J. Keen
// Date             : 13 June 2017
//
// Description      : Module factory_test.c provides a set of serial commands 
//                    to manipulate the LCU's hardware to allow control by ATE 
//                    during production test
//
//
////////////////////////////////////////////////////////////////////////////////

#include "factory_test.h"

#include "rvs.h"

#include "hal.h"
#include "common_types.h"

////////////////////////////////////////////////////////////////////////////////
//
// Defines
//
////////////////////////////////////////////////////////////////////////////////

// Software definitions
#define MAX_CODE_BYTES                   0X7FFFU      ///< Total code size of the 32K microcontroller

#define SOFTWARE_PART_NUMBER             0x9AAAU   ///< software library Number 39594-E
#define SOFTWARE_ISSUE_NUMBER            0x04U

// Antenna table table PDI
#define TABLE_CRC_CALC_MAX_ATTEMPTS      10U
#define ANTENNA_TABLE_COUNT              4U        ///< Number of stored antenna table PDIs

// Radio Presets PDI
#define RADIO_PRESETS_ADDR               FLASH_SECTOR_9_ADDRESS + 2
#define RADIO_PRESETS_SECTOR             FLASH_SECTOR_9
#define RADIO_PRESETS_HEADER_ADDR        FLASH_SECTOR_9_ADDRESS + 16
#define RADIO_PRESETS_HEADER_SIZE        4U

#define RADIO_PRESETS_ID_MSB             0x9BU     ///< Format ID = 39928
#define RADIO_PRESETS_ID_LSB             0xF8U

#define RADIO_PRESETS_VERSION_MSB        0x00U
#define RADIO_PRESETS_VERSION_LSB        0x01U

#define RADIO_PRESETS_DEFAULT            0x00U     ///< Default Radio Preset to ARC210 GEN 4

#define RADIO_PRESETS_VALUES_COUNT       7U        ///< Number of radio presets stored in PDI

// Forcing Bytes PDI
#define FORCING_BYTES_ADDR               FLASH_SECTOR_10_ADDRESS
#define FORCING_BYTES_SECTOR             FLASH_SECTOR_10
#define FORCING_BYTES_HEADER_ADDR        FLASH_SECTOR_10_ADDRESS + 2
#define FORCING_BYTES_HEADER_SIZE        4U
#define FORCING_BYTES_TABLE_SIZE         6U

#define FORCING_BYTES_ID_MSB             0x9BU     ///< Format ID = 39929
#define FORCING_BYTES_ID_LSB             0xF9U

#define FORCING_BYTES_VERSION_MSB        0x00U
#define FORCING_BYTES_VERSION_LSB        0x01U

#define FORCING_BYTES_DEFAULT_MSB        0xFFU
#define FORCING_BYTES_DEFAULT_LSB        0xFFU

// Factory Test Command IDs
#define WRITE_CPLD_CONTROL_REGISTER      0X00U          ///< write to CPLD internal 8 bit latch
#define READ_CPLD_CONTROL_REGISTER       0X01U          ///< read from CPLD internal 8 bit latch
#define CONTROL_OUTPUT_LED               0X02U          ///< set output BIT LED (box lower)
#define CONTROL_INPUT_LED                0X03U            ///< set input BIT LED (box upper)
#define UNLOCK                           0X04U          ///< command to unlock flash memory write/erase

#define FULL_FLASH_ERASE                 0X24U          ///< erase entire flash memory

#define READ_MICROCONTROLLER_CRC         0X32U          ///< return microcontroller CRC-16

#define SET_DRIVE_LINE_STATE             0X40U          ///< for output driveline test
#define MICRO_BOOTLOADER                 0X50U          ///< reset to bootloader

#define SET_J1_FAULT_OUTPUT              0X60U          ///< Drive output BIT discrete at J1
#define SET_JTAG_SOURCE                  0X61U

#define SET_BAUD_RATE                    0X62U
#define ERASE_FLASH_SECTOR               0X63U          ///< erase flash sector
#define CALCULATE_ANTENNA_TABLE_CRC      0X64U            ///< calculate and return antenna table CRC
#define CALCULATE_RADIO_CRC              0X65U            ///< calculate and return CRC of the radio type configuration block

#define SET_PCB_DIAGNOSTIC_LED           0X66U            ///< Control PCB green diagnostic LED
#define WRITE_TO_PORT_EXPANDER           0X67U            ///< write to PCF8574A port expander

#define CONFIGURE_RADIO_DATA_INPUTS      0X68U
#define WRITE_TO_ETI                     0X69U
#define READ_FROM_ETI                    0X6AU
#define READ_ETI_TIME                    0X6BU

#define WRITE_TO_128K_RAM                0X6CU
#define READ_128K_RAM                    0X6DU

#define LOAD_FORCING_BYTES               0X6EU
#define READ_BACK_FORCING_BYTES          0X6FU

#define WRITE_PARALLEL_FLASH_POINTER     0X70U
#define READ_PARALLEL_FLASH_POINTER      0X71U

#define WRITE_FLASH_DATA                 0X72U
#define READ_FLASH_DATA                  0X73U

#define WRITE_CONFIG_TABLE               0X74U
#define READ_CONFIG_TABLE                0X75U

#define READ_CONFIGURATION_STRING        0X76U
#define READ_DRIVER_OK                   0X77U

#define READ_SOFTWARE_PART_NO            0x78U
#define READ_PLD_PART_NO                 0x79U

#define DUMP_CODE_COVERAGE_MAP           0x99U

////////////////////////////////////////////////////////////////////////////////
//
// Global variables
//
////////////////////////////////////////////////////////////////////////////////

static unsigned long flashAddressPointer;                   // Address for flash memory operations

// this global makes use of the 8051s bit handling capabilities to simply remap the driveline bits
// it does not retain its data

// Antenna drive line state
static unsigned char bdata Map;
sbit Map_01     = Map^0;
sbit Map_02     = Map^1;
sbit Map_04     = Map^2;
sbit Map_08     = Map^3;
sbit Map_10     = Map^4;
sbit Map_20     = Map^5;
sbit Map_40     = Map^6;
sbit Map_80     = Map^7;

// these 2 globals are used in order to make the drivelines bit addressable using the 8051's bit handling capabilities
// Data for Antenna Drive Line Register MSB (Base + 0x06)
static unsigned char bdata Drive_High_Data;
sbit Drive_K        = Drive_High_Data^0;
sbit Drive_J        = Drive_High_Data^1;
sbit Drive_A        = Drive_High_Data^2;
sbit Drive_B        = Drive_High_Data^3;
sbit Drive_C        = Drive_High_Data^4;
sbit Drive_D        = Drive_High_Data^5;
sbit Drive_E        = Drive_High_Data^6;
sbit Drive_F        = Drive_High_Data^7;

// Data for Antenna Drive Line Register LSB (Base + 0x05)
static unsigned char bdata Drive_Low_Data;
sbit Drive_H        = Drive_Low_Data^0;     
//sbit Reserved     = Drive_Low_Data^1;
sbit Lines_0        = Drive_Low_Data^2;
sbit Lines_1        = Drive_Low_Data^3;
//sbit Spare        = Drive_Low_Data^4;
//sbit Spare        = Drive_Low_Data^5;
//sbit Spare        = Drive_Low_Data^6;
sbit Enable         = Drive_Low_Data^7;     // 1 = output drive at J3 driven from CPLD Antenna Drive registers, 0 = output at J3 driven directly from FLASH data line outputs

////////////////////////////////////////////////////////////////////////////////
//
// External global variables
//
////////////////////////////////////////////////////////////////////////////////

extern bit uartTxActive;
extern bit commandAvailable;
extern unsigned char xdata commandBuffer[COMMAND_BUFFER_SIZE];

////////////////////////////////////////////////////////////////////////////////
//
// Local function declarations
//
////////////////////////////////////////////////////////////////////////////////

static void FACTORY_TEST_Init(void);

static unsigned char FACTORY_TEST_TryUnlock(unsigned char Command_Code);
static void FACTORY_TEST_CommandProcessor(unsigned char Command_Code);

// Command handlers
static void FACTORY_TEST_ComWriteCpldControlRegister(void);
static void FACTORY_TEST_ComReadCpldControlRegister(void);
static void FACTORY_TEST_ComControlOutputLed(void);
static void FACTORY_TEST_ComControlInputLed(void);
static void FACTORY_TEST_ComSetPcbDiagnosticLed(void);
static void FACTORY_TEST_ComSetJ1FaultOutput(void);
static void FACTORY_TEST_ComSetBaudRate(void);
static void FACTORY_TEST_ComConfigureRadioDataInputs(void);
static void FACTORY_TEST_ComWriteParallelFlashPointer(void);
static void FACTORY_TEST_ComReadParallelFlashPointer(void);
static void FACTORY_TEST_ComWriteFlashData(void);
static void FACTORY_TEST_ComReadFlashData(void);
static void FACTORY_TEST_ComEraseFlashSector(void);
static void FACTORY_TEST_ComFullFlashErase(void);
static void FACTORY_TEST_ComCalculateAntennaTableCrc(void);
static void FACTORY_TEST_ComReadMicrocontroller_Crc(void);
static void FACTORY_TEST_ComSetDriveLineState(void);
static void FACTORY_TEST_ComMicroBootloader(void);
static void FACTORY_TEST_ComReadEtiTime(void);
static void FACTORY_TEST_ComWriteToEti(void);
static void FACTORY_TEST_ComReadFromEti(void);
static void FACTORY_TEST_ComWriteToBusExpander(void);
static void FACTORY_TEST_ComWriteTo128kRam(void);
static void FACTORY_TEST_ComRead128kRam(void);
static void FACTORY_TEST_ComSetJtagSource(void);
static void FACTORY_TEST_ComReadConfigTable(void);
static void FACTORY_TEST_ComLoadForcingBytes(void);
static void FACTORY_TEST_ComReadBackForcingBytes(void);
static void FACTORY_TEST_ComReadDriverOk(void);
static void FACTORY_TEST_ComWriteConfigTable(void);
static void FACTORY_TEST_ComCalculateRadioCrc(void);
static void FACTORY_TEST_ComReadConfigurationString(void);
static void FACTORY_TEST_ComReadSoftwarePartNumber(void);
static void FACTORY_TEST_ComReadPldPartNumber(void);

static unsigned char FACTORY_TEST_IsUnlockString(char Str[]);

static unsigned char FACTORY_TEST_RadioTypeIsValid(unsigned char radioTypeId);
static unsigned char FACTORY_TEST_RadioPresetsIsValid(void);
static unsigned char FACTORY_TEST_ForcingBytesIsValid(void);

static unsigned int FACTORY_TEST_CalculateMicroCrc(void);
static unsigned int FACTORY_TEST_CalculateAntennaTableCrc(unsigned char antennaTable);
static unsigned int FACTORY_TEST_CalculateRadioPresetsCrc(void);
static unsigned int FACTORY_TEST_CalculateForcingBytesCrc(void);

extern void reboot(void);

////////////////////////////////////////////////////////////////////////////////
//
// Function definitions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Enters Factory Test Mode in locked state
///
/// Enters Factory Test Mode in locked state.
/// Function loops forever pending on commands
/// received over the Factory Test Interface.
/// A valid unlock command needs to be received
/// before the function will allow other Factory
/// Test commands to be executed.
/// uses the global variable commandAvailable

extern void FACTORY_TEST_Run(void)
{
  unsigned char lockedStatus = TRUE;
  unsigned char commandCode;

  FACTORY_TEST_Init();

  while (TRUE)                                              // until power-down
  {
    if (commandAvailable)                                   // if a factory test interface command has been received
    {
      commandAvailable = FALSE;

      commandCode = HAL_UartGetHexPair(1);                  // get the code for the required action

      if (lockedStatus == TRUE)
      {
        lockedStatus = FACTORY_TEST_TryUnlock(commandCode); // process the received command and return locked status
      }
      else
      {
        FACTORY_TEST_CommandProcessor(commandCode);         // process the received command
        HAL_FlushCommandBuffer();                           // flush command from command line buffer
      }
    }

    HAL_FlashInputLed(lockedStatus);                        // Flash input LED to notify that Factory test locked state is selected
  }
}

static void FACTORY_TEST_Init(void)
{
  Drive_H = VOLTAGE_STATE;
  Lines_0 = 0;
  Lines_1 = 0;
  Enable = 1;                               // enable antenna outputs at J3 to be driven by microcontroller

  Drive_K = VOLTAGE_STATE;
  Drive_J = VOLTAGE_STATE;
  Drive_A = VOLTAGE_STATE;
  Drive_B = VOLTAGE_STATE;
  Drive_C = VOLTAGE_STATE;
  Drive_D = VOLTAGE_STATE;
  Drive_E = VOLTAGE_STATE;
  Drive_F = VOLTAGE_STATE;

  HAL_PldWriteLatch(PLD_REG_ANTDRIVE_HIGH, Drive_High_Data);
  HAL_PldWriteLatch(PLD_REG_ANTDRIVE_LOW,  Drive_Low_Data);
}

/// \brief Attempts to unlock Factory Test Mode
///
/// Attempts to unlock Factory Test Mode if
/// passed command ID equals UNLOCK. Tests the
/// contents of the command buffer to see if
/// it contains the unlock string. Returns
/// whether unlock attempt was successful.
/// uses the global variable commandBuffer
///
/// \param commandCode Command ID of command
///
/// \return Returns '1' if successfully unlock,
///         otherwise '0'

static unsigned char FACTORY_TEST_TryUnlock(unsigned char commandCode)
{
  unsigned char locked = TRUE;

  if (commandCode == UNLOCK)
  {
    if (FACTORY_TEST_IsUnlockString(commandBuffer) == TRUE)
    {
      HAL_SetInputLed(OFF);

      // Enable UART TX
      HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_TX_ENABLED);

      locked = FALSE;
    }
  }

  return locked;
}

/// \brief Dispatches command to appropiate command handler
///
/// Function dispatches the passed commandCode to the
/// appropiate command handler.
///
/// \param commandCode Command ID of command to handle

static void FACTORY_TEST_CommandProcessor(unsigned char commandCode)
{
  if (HAL_PldIsCompatible() == TRUE)
  {
    switch (commandCode)
    {
    case WRITE_CPLD_CONTROL_REGISTER:
      FACTORY_TEST_ComWriteCpldControlRegister();

      break;

    case READ_CPLD_CONTROL_REGISTER:
      FACTORY_TEST_ComReadCpldControlRegister();

      break;

    case CONTROL_OUTPUT_LED:
      FACTORY_TEST_ComControlOutputLed();

      break;

    case CONTROL_INPUT_LED:
      FACTORY_TEST_ComControlInputLed();

      break;

    case SET_PCB_DIAGNOSTIC_LED:
      FACTORY_TEST_ComSetPcbDiagnosticLed();

      break;

    case SET_J1_FAULT_OUTPUT:
      FACTORY_TEST_ComSetJ1FaultOutput();

      break;

    case SET_BAUD_RATE:
      FACTORY_TEST_ComSetBaudRate();

      break;

    case CONFIGURE_RADIO_DATA_INPUTS:
      FACTORY_TEST_ComConfigureRadioDataInputs();

      break;

    case WRITE_PARALLEL_FLASH_POINTER:
      FACTORY_TEST_ComWriteParallelFlashPointer();

      break;

    case READ_PARALLEL_FLASH_POINTER:
      FACTORY_TEST_ComReadParallelFlashPointer();

      break;

    case WRITE_FLASH_DATA:
      FACTORY_TEST_ComWriteFlashData();

      break;

    case READ_FLASH_DATA:
      FACTORY_TEST_ComReadFlashData();

      break;

    case ERASE_FLASH_SECTOR:
      FACTORY_TEST_ComEraseFlashSector();

      break;

    case FULL_FLASH_ERASE :
      FACTORY_TEST_ComFullFlashErase();

      break;

    case CALCULATE_ANTENNA_TABLE_CRC:
      FACTORY_TEST_ComCalculateAntennaTableCrc();

      break;

    case READ_MICROCONTROLLER_CRC:
      FACTORY_TEST_ComReadMicrocontroller_Crc();

      break;

    case SET_DRIVE_LINE_STATE:
      FACTORY_TEST_ComSetDriveLineState();

      break;

    case MICRO_BOOTLOADER:
#pragma RVS instrumentation_point;
      FACTORY_TEST_ComMicroBootloader();

      break;

    case READ_ETI_TIME:
      FACTORY_TEST_ComReadEtiTime();

      break;

    case WRITE_TO_ETI:
      FACTORY_TEST_ComWriteToEti();

      break;

    case READ_FROM_ETI:
      FACTORY_TEST_ComReadFromEti();

      break;

    case WRITE_TO_PORT_EXPANDER:
      FACTORY_TEST_ComWriteToBusExpander();

      break;

    case WRITE_TO_128K_RAM:
      FACTORY_TEST_ComWriteTo128kRam();

      break;

    case READ_128K_RAM:
      FACTORY_TEST_ComRead128kRam();

      break;

    case SET_JTAG_SOURCE:
      FACTORY_TEST_ComSetJtagSource();

      break;

    case WRITE_CONFIG_TABLE:
      FACTORY_TEST_ComWriteConfigTable();

      break;

    case READ_CONFIG_TABLE:
      FACTORY_TEST_ComReadConfigTable();

      break;

    case CALCULATE_RADIO_CRC:
      FACTORY_TEST_ComCalculateRadioCrc();

      break;

    case LOAD_FORCING_BYTES:
      FACTORY_TEST_ComLoadForcingBytes();

      break;

    case READ_BACK_FORCING_BYTES:
      FACTORY_TEST_ComReadBackForcingBytes();

      break;

    case READ_CONFIGURATION_STRING:
      FACTORY_TEST_ComReadConfigurationString();

      break;

    case READ_DRIVER_OK:
      FACTORY_TEST_ComReadDriverOk();

      break;

    case READ_SOFTWARE_PART_NO:
      FACTORY_TEST_ComReadSoftwarePartNumber();

      break;

    case READ_PLD_PART_NO:
      FACTORY_TEST_ComReadPldPartNumber();

      break;

    case DUMP_CODE_COVERAGE_MAP:
#pragma RVS add_statement("RVS_Output()")
      break;
    }
  }
  else
  {
    switch (commandCode)
    {
    case SET_JTAG_SOURCE:
      FACTORY_TEST_ComSetJtagSource();

      break;

    case MICRO_BOOTLOADER:
#pragma RVS instrumentation_point;
      FACTORY_TEST_ComMicroBootloader();

      break;

    case DUMP_CODE_COVERAGE_MAP:
#pragma RVS add_statement("RVS_Output()")
      break;
    }
  }
}

////////////////////////////////////////////////////////////////////////////////
//
// Command handler function definitions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Handler for WRITE CPLD CONTROL REGISTER command
///
/// Factory Test handler for WRITE CPLD CONTROL REGISTER
/// command. Writes to the PLD register specified by the
/// command parameter.
/// uses the global variable commandBuffer

static void FACTORY_TEST_ComWriteCpldControlRegister(void)
{
  unsigned int addr;
  unsigned char value;

  if (HAL_CommandBufferNumberOfArgs() == 2)
  {
    addr = (int)HAL_UartGetHexPair(2) + (int)PLD_BASE_ADDR;
    value = HAL_UartGetHexPair(3);

    HAL_PldWriteLatch(addr, value);
  }
}

/// \brief Handler for READ CPLD CONTROL REGISTER command
///
/// Factory Test handler for READ CPLD CONTROL REGISTER
/// command. Reads the PLD register specified by the
/// command parameter and outputs the register's value
/// over the Factory Test Interface.
/// uses the global variable commandBuffer

static void FACTORY_TEST_ComReadCpldControlRegister(void)
{
  unsigned int addr;
  unsigned char value;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    addr = (int)HAL_UartGetHexPair(2) + PLD_BASE_ADDR;

    value = HAL_PldReadLatch(addr);

    HAL_UartPrintHex(value, 2);
    HAL_UartPutChar('\r');
    HAL_UartPutChar('\n');
  }
}

/// \brief Handler for CONTROL OUTPUT LED command
///
/// Factory Test handler for CONTROL OUTPUT LED
/// command. Sets the state of the Output LED.

static void FACTORY_TEST_ComControlOutputLed(void)
{
  unsigned char ledState;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    ledState = HAL_UartGetHexPair(2);

    HAL_SetOutputLed(ledState);
  }
}

/// \brief Handler for CONTROL INPUT LED command
///
/// Factory Test handler for CONTROL INPUT LED
/// command. Sets the state of the Input LED.

static void FACTORY_TEST_ComControlInputLed(void)
{
  unsigned char ledState;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    ledState = HAL_UartGetHexPair(2);
    HAL_SetInputLed(ledState);
  }
}

/// \brief Handler for SET PCB DIAGNOSTIC LED command
///
/// Factory Test handler for SET PCB DIAGNOSTIC LED
/// command. Sets the state of the PCB LED.

static void FACTORY_TEST_ComSetPcbDiagnosticLed(void)
{
  unsigned char ledState;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    ledState = HAL_UartGetHexPair(2);
    HAL_SetPcbLed(ledState);
  }
}

/// \brief Handler for SET J1 FAULT OUTPUT command
///
/// Factory Test handler for SET J1 FAULT OUTPUT
/// command. Sets the state of the J1 Fault line.

static void FACTORY_TEST_ComSetJ1FaultOutput(void)
{
  unsigned char radioBitState;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    radioBitState = HAL_UartGetHexPair(2);

    if (radioBitState == 1)
    {
      // switch driver mosfet to GND (no fault)
      HAL_PldLatchClearBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_PBIT_FAIL);   // set Fault output control bit to 0
    }
    else if (radioBitState == 0)
    {
      // switch driver mosfet to O/C (fault)
      HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_PBIT_FAIL);     // set Fault output control bit to 1
    }
  }
}

/// \brief Handler for SET BAUD RATE command
///
/// Factory Test handler for SET BAUD RATE
/// command. Changes the baud rate of the
/// Factory Test Interface.
/// uses the global variable uartTxActive

static void FACTORY_TEST_ComSetBaudRate(void)
{
  unsigned char newBaudRate;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    newBaudRate = HAL_UartGetHexPair(2);
        
    if (newBaudRate <= BAUD_115200)
    {
      while (uartTxActive)                           // wait for transmit buffer to empty
      {
        // Do Nothing
      }
      
      HAL_UartInit(newBaudRate);
    }
  }
}

/// \brief Handler for CONFIGURE RADIO DATA INPUTS command
///
/// Factory Test handler for CONFIGURE RADIO DATA INPUTS
/// command. Sets the Radio Data input to either single
/// ended or differential.

static void FACTORY_TEST_ComConfigureRadioDataInputs(void)
{
  unsigned char dataInputConfig;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    dataInputConfig = HAL_UartGetHexPair(2);

    if (dataInputConfig == 1)
    {
      // J1 Clock and Data inputs to single-ended
      HAL_PldLatchSetBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_SINGLE_ENDED);
    }
    else if (dataInputConfig == 0)
    {
      // J1 Clock and Data inputs to differential
      HAL_PldLatchClearBitMask(PLD_REG_CONTROL_1, PLD_CONTROL_1_SINGLE_ENDED);
    }
  }
}

/// \brief Handler for READ PARALLEL FLASH POINTER command
///
/// Factory Test handler for READ PARALLEL FLASH POINTER
/// command. Outputs the current address pointed to
/// by the flash address pointer over the Factory
/// Test Interface.

// uses the global variable flashAddressPointer

static void FACTORY_TEST_ComWriteParallelFlashPointer(void)
{
  unsigned char addrHigh;
  unsigned char addrMid;
  unsigned char addrLow;

  if (HAL_CommandBufferNumberOfArgs() == 3)
  {
    addrHigh = HAL_UartGetHexPair(2);
    addrMid  = HAL_UartGetHexPair(3);
    addrLow  = HAL_UartGetHexPair(4);

    flashAddressPointer = (unsigned long)addrLow;
    flashAddressPointer |= (unsigned long)addrMid  << 8;
    flashAddressPointer |= (unsigned long)addrHigh << 16;
  }
}

/// \brief Handler for READ PARALLEL FLASH POINTER command
///
/// Factory Test handler for READ PARALLEL FLASH POINTER
/// command. Outputs the current address pointed to
/// by the flash address pointer over the Factory
/// Test Interface.

// uses the global variable flashAddressPointer

static void FACTORY_TEST_ComReadParallelFlashPointer(void)
{
  HAL_UartPrintHex(flashAddressPointer, 6);
  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for WRITE FLASH DATA command
///
/// Factory Test handler for WRITE FLASH DATA
/// command. Writes bytes in command buffer to
/// flash. Outputs over Factory Test Interface
/// '.' on success or 'X' on failure.

// uses the global variable flashAddressPointer

static void FACTORY_TEST_ComWriteFlashData(void)
{
  unsigned char bytesWritten;

  bytesWritten = HAL_UartWriteCommandBufferToFlash(flashAddressPointer);

  flashAddressPointer += (unsigned long)bytesWritten;

  if (bytesWritten > 0)
  {
    HAL_UartPutChar('.');                           // signal to host that the program operation has successfully completed
  }
  else
  {
    HAL_UartPutChar('X');                           // signal to the host that the program operation has failed
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for READ FLASH DATA command
///
/// Factory Test handler for READ FLASH DATA
/// command. Reads a byte from flash at the
/// address pointed to by the internal
/// address pointer. Prints the read value
/// over the Factory Test Interface.

// uses the global variable flashAddressPointer

static void FACTORY_TEST_ComReadFlashData(void)
{
  unsigned char value = HAL_FlashRead(flashAddressPointer);

  flashAddressPointer++;

  HAL_UartPrintHex((long)value, 2);
  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for ERASE FLASH SECTOR command
///
/// Factory Test handler for ERASE FLASH SECTOR
/// command. Erases the sector of flash specified
/// by the command parameter. Outputs over
/// Factory Test Interface '.' on success or
/// 'X' on failure.

static void FACTORY_TEST_ComEraseFlashSector(void)
{
  unsigned char flashSector;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    flashSector = HAL_UartGetHexPair(2);

    if (flashSector <= FLASH_MAX_SECTORS)
    {
      if (HAL_FlashEraseSector(flashSector) == SUCCESS)
      {
        HAL_UartPutChar('.');                   // signal to host that erase operation has successfully completed
      }
      else
      {
        HAL_UartPutChar('X');                   // signal to the host that erase operation has failed
      }
    }
    else
    {
      HAL_UartPutChar('X');                     // signal to host that the sector is out of range
    }

    HAL_UartPutChar('\r');
    HAL_UartPutChar('\n');
  }

}

/// \brief Handler for FULL FLASH ERASE  command
///
/// Factory Test handler for FULL FLASH ERASE
/// command. Erases all of the external flash.
/// Outputs over Factory Test Interface '.'
/// on success or 'X' on failure.

static void FACTORY_TEST_ComFullFlashErase(void)
{
  if (HAL_FlashEraseChip() == SUCCESS)
  {
    HAL_UartPutChar('.');                      // signal to host that erase operation has successfully completed
  }
  else
  {
    HAL_UartPutChar('X');                      // signal to the host that erase operation has failed
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for CALCULATE ANTENNA TABLE CRC command
///
/// Factory Test handler for CALCULATE ANTENNA TABLE CRC
/// command. Returns the CRC of the Antenna Table specified
/// by the command parameter.

static void FACTORY_TEST_ComCalculateAntennaTableCrc(void)
{
  unsigned char antennaTable;
  unsigned int crc;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    antennaTable = HAL_UartGetHexPair(2);

    crc = FACTORY_TEST_CalculateAntennaTableCrc(antennaTable);

    HAL_UartPrintHex((long)crc, 4);
    HAL_UartPutChar('\r');
    HAL_UartPutChar('\n');
  }
}

/// \brief Handler for READ MICROCONTROLLER CRC command
///
/// Factory Test handler for READ MICROCONTROLLER CRC
/// command. Returns the CRC of the micro-controller
/// software over the Factory Test Interface.

static void FACTORY_TEST_ComReadMicrocontroller_Crc(void)
{
  unsigned int microCrc;

  microCrc = FACTORY_TEST_CalculateMicroCrc();

  HAL_UartPrintHex((long)microCrc, 4);
  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for SET DRIVE LINE STATE command
///
/// Factory Test handler for SET DRIVE LINE STATE
/// command. Sets the state of the Antenna Drive
/// Lines according to the parameters passed with
/// the command.

// uses the global variable map

static void FACTORY_TEST_ComSetDriveLineState(void)
{

  if (HAL_CommandBufferNumberOfArgs() == 2)
  {
    Map = HAL_UartGetHexPair(2);

    Drive_H = Map_01;
    Drive_K = Map_10;
    Drive_J = Map_20;
    Drive_A = Map_40;
    Drive_B = Map_80;

    Map = HAL_UartGetHexPair(3);

    Drive_C = Map_01;
    Drive_D = Map_02;
    Drive_E = Map_04;
    Drive_F = Map_08;
    Lines_0 = Map_10;
    Lines_1 = Map_20;

    Enable = 1;                             // enable antenna outputs at J3 to be driven by microcontroller

    HAL_PldWriteLatch(PLD_REG_ANTDRIVE_HIGH, Drive_High_Data);
    HAL_PldWriteLatch(PLD_REG_ANTDRIVE_LOW,  Drive_Low_Data);
  }
}

/// \brief Handler for MICRO BOOTLOADER command
///
/// Factory Test handler for MICRO BOOTLOADER
/// command. Puts the micro-controller into
/// it's built in bootloader to allow the
/// software to be updated.
/// uses the global variable uartTxActive

static void FACTORY_TEST_ComMicroBootloader(void)
{
  HAL_SetInputLed(OFF);
  HAL_SetOutputLed(OFF);

  HAL_UartPutChar('\n');
  HAL_UartPutChar('\n');
  HAL_UartPutChar('R');
  HAL_UartPutChar('E');
  HAL_UartPutChar('A');
  HAL_UartPutChar('D');
  HAL_UartPutChar('Y');
  HAL_UartPutChar('>');
  HAL_UartPutChar('\r');

  while (uartTxActive)                                // wait for transmit buffer to empty
  {
    // Do nothing
  }

#pragma RVS instrumentation_point;

#pragma RVS add_statement("RVS_Output()")

  reboot();                                           // boot up into ISP mode
}

/// \brief Handler for READ ETI TIME command
///
/// Factory Test handler for READ ETI TIME
/// command. Reads the elapsed time from
/// the ETI device and outputs the time over
/// the Factory Test Interface.

static void FACTORY_TEST_ComReadEtiTime(void)
{
  HAL_UartPrintHex((long)HAL_EtiReadReg(0x08), 2);   // High Byte
  HAL_UartPrintHex((long)HAL_EtiReadReg(0x07), 2);   // High-Middle Byte
  HAL_UartPrintHex((long)HAL_EtiReadReg(0x06), 2);   // Low-Middle Byte
  HAL_UartPrintHex((long)HAL_EtiReadReg(0x05), 2);   // Low Byte

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for WRITE TO ETI command
///
/// Factory Test handler for WRITE TO ETI
/// command. Writes a byte to the ETI device
/// address specified by the command parameter.

static void FACTORY_TEST_ComWriteToEti(void)
{
  unsigned char address;
  unsigned char value;

  if (HAL_CommandBufferNumberOfArgs() == 2)
  {
    address = HAL_UartGetHexPair(2);
    value   = HAL_UartGetHexPair(3);

    HAL_EtiWriteReg(address, value);
  }
}

/// \brief Handler for READ FROM ETI command
///
/// Factory Test handler for READ FROM ETI
/// command. Reads a byte from the ETI
/// device. The address of the ETI register
/// is passed as a parameter to the command.

static void FACTORY_TEST_ComReadFromEti(void)
{
  unsigned char address;
  unsigned char value;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    address = HAL_UartGetHexPair(2);
    value   = HAL_EtiReadReg(address);

    HAL_UartPrintHex((long)value, 2);

    HAL_UartPutChar('\r');
    HAL_UartPutChar('\n');
  }
}

/// \brief Handler for WRITE TO PORT EXPANDER  command
///
/// Factory Test handler for WRITE TO PORT EXPANDER
/// command. Write a byte passed as a command
/// parameter to the bus expander.

static void FACTORY_TEST_ComWriteToBusExpander(void)
{
  unsigned char value;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    value = HAL_UartGetHexPair(2);

    HAL_BusExpanderWrite(value);
  }
}

/// \brief Handler for WRITE TO 128K RAM command
///
/// Factory Test handler for WRITE TO 128K RAM
/// command. Write a byte to the 128K RAM
/// device. The address to write to is
/// specified by 3 bytes passed as part of
/// the command.

static void FACTORY_TEST_ComWriteTo128kRam(void)
{
  unsigned char addressHigh;
  unsigned char addressMid;
  unsigned char addressLow;
  unsigned char value;

  if (HAL_CommandBufferNumberOfArgs() == 4)
  {
    addressHigh = HAL_UartGetHexPair(2);
    addressMid  = HAL_UartGetHexPair(3);
    addressLow  = HAL_UartGetHexPair(4);
    value       = HAL_UartGetHexPair(5);

    HAL_RamWrite(addressHigh, addressMid, addressLow, value);
  }
}

/// \brief Handler for READ 128K RAM command
///
/// Factory Test handler for READ 128K RAM
/// command. Reads a byte from the 128K RAM
/// device and outputs it over the Factory
/// Test Interface. The address read from is
/// specified by 3 bytes passed as part of
/// the command.

static void FACTORY_TEST_ComRead128kRam(void)
{
  unsigned char addressHigh;
  unsigned char addressMid;
  unsigned char addressLow;
  unsigned int  value;

  if (HAL_CommandBufferNumberOfArgs() == 3)
  {
    addressHigh = HAL_UartGetHexPair(2);
    addressMid  = HAL_UartGetHexPair(3);
    addressLow  = HAL_UartGetHexPair(4);

    value = HAL_RamRead(addressHigh, addressMid, addressLow);

    HAL_UartPrintHex((long)value, 2);

    HAL_UartPutChar('\r');
    HAL_UartPutChar('\n');
  }
}

/// \brief Handler for SET JTAG SOURCE command
///
/// Factory Test handler for SET JTAG SOURCE
/// command. Sets the source of the PLD JTAG
/// via the PCF8574 bus expander device.

static void FACTORY_TEST_ComSetJtagSource(void)
{
  unsigned char jtagSource;

  if (HAL_CommandBufferNumberOfArgs() == 1)
  {
    jtagSource = HAL_UartGetHexPair(2);

    if (jtagSource == 0)
    {
      // Route JTAG to J1
      HAL_BusExpanderWrite(JTAG_SOURCE_J1);
    }
    else if (jtagSource == 1)
    {
      // Route JTAG to PCB socket
      HAL_BusExpanderWrite(JTAG_SOURCE_PCB);
    }
  }
}

/// \brief Handler for READ CONFIG TABLE command
///
/// Factory Test handler for READ CONFIG TABLE
/// command. Outputs over the Factory Test Interface
/// the Radio Presets values.

static void FACTORY_TEST_ComReadConfigTable(void)
{
  unsigned long address;
  unsigned char isValid;
  unsigned char i;

  address = RADIO_PRESETS_ADDR;

  isValid = FACTORY_TEST_RadioPresetsIsValid();

  for (i = 0; i < RADIO_PRESETS_VALUES_COUNT; i++)

  {
    if (isValid)
    {
      HAL_UartPrintHex((long)HAL_FlashRead(address), 2);
    }
    else
    {
      HAL_UartPrintHex((long)RADIO_PRESETS_DEFAULT, 2);
    }

    // Radio presets are stored aligned to 16-bit words, so skip 2 bytes
    address += 2;
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for CALCULATE RADIO CRC command
///
/// Factory Test handler for CALCULATE RADIO CRC
/// command. Outputs over the Factory Test Interface
/// the Radio Presets CRC.

static void FACTORY_TEST_ComCalculateRadioCrc(void)
{
  unsigned int crc;

  crc = FACTORY_TEST_CalculateRadioPresetsCrc();

  HAL_UartPrintHex((long)crc, 4);
  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for LOAD FORCING BYTES command
///
/// Factory Test handler for LOAD FORCING BYTES
/// command. Writes the Forcing Bytes passed as
/// part of the command to flash. Outputs over
/// Factory Test Interface '.' on success or 'X'
/// on failure.

static void FACTORY_TEST_ComLoadForcingBytes(void)
{
  unsigned char code forcingBytesHeader[FORCING_BYTES_HEADER_SIZE] = {FORCING_BYTES_ID_LSB,
                                                                      FORCING_BYTES_ID_MSB,
                                                                      FORCING_BYTES_VERSION_LSB,
                                                                      FORCING_BYTES_VERSION_MSB};
  unsigned int  forcingBytesCrc;
  unsigned char status;
  unsigned char writeByte;
  unsigned long address;
  unsigned char i;

  status = SUCCESS;

  address = FORCING_BYTES_ADDR;

  if (HAL_CommandBufferNumberOfArgs() == 2)
  {
    if (HAL_FlashEraseSector(FORCING_BYTES_SECTOR) == SUCCESS)
    {
      // Write Forcing Bytes values
      writeByte = HAL_UartGetHexPair(3);              // get second forcing byte (word mode LSB)
      status &= HAL_FlashWriteAndVerify(address, writeByte);

      address++;

      writeByte = HAL_UartGetHexPair(2);            // get first forcing byte (word mode MSB)
      status &= HAL_FlashWriteAndVerify(address, writeByte);

      address++;

      // Write Forcing Bytes PDI header
      for (i = 0; i < FORCING_BYTES_HEADER_SIZE; i++)
      {
        status &= HAL_FlashWriteAndVerify(address, forcingBytesHeader[i]);

        address++;
      }

      if (status != FAIL)
      {
        forcingBytesCrc = FACTORY_TEST_CalculateForcingBytesCrc();

        // Write Forcing Bytes PDI CRC
        writeByte = (unsigned char)(forcingBytesCrc & 0x00FF);        // write crc LSB
        status &= HAL_FlashWriteAndVerify(address, writeByte);
        address++;

        writeByte = (unsigned char)((forcingBytesCrc & 0xFF00) >> 8); // write crc MSB
        status &= HAL_FlashWriteAndVerify(address, writeByte);
      }
    }
    else
    {
      status = FAIL;
    }
  }
  else
  {
    status = FAIL;
  }

  if (status == SUCCESS)
  {
    HAL_UartPutChar('.');         // signal to host that erase operation has successfully completed
  }
  else
  {
    HAL_UartPutChar('X');         // signal to the host that erase operation has failed
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for READ BACK FORCING BYTES command
///
/// Factory Test handler for READ BACK FORCING BYTES
/// command. Outputs the Forcing Bytes over the
/// Factory Test Interface.

static void FACTORY_TEST_ComReadBackForcingBytes(void)
{
  if (FACTORY_TEST_ForcingBytesIsValid() == TRUE)
  {
    HAL_UartPrintHex((long)HAL_FlashRead(FORCING_BYTES_ADDR + 1), 2);   // get first forcing byte (word mode MSB)
    HAL_UartPrintHex((long)HAL_FlashRead(FORCING_BYTES_ADDR ), 2);      // get second forcing byte (word mode LSB)
  }
  else
  {
    HAL_UartPrintHex((long)FORCING_BYTES_DEFAULT_MSB, 2);
    HAL_UartPrintHex((long)FORCING_BYTES_DEFAULT_LSB, 2);
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for READ DRIVER OK command
///
/// Factory Test handler for READ DRIVER OK
/// command. Outputs the BIT status of the
/// driver card: '1' for pass, '0' for fail.

static void FACTORY_TEST_ComReadDriverOk(void)
{
  if (DriverBitOk == 1)
  {
    HAL_UartPutChar('1');
  }
  else
  {
    HAL_UartPutChar('0');
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for WRITE CONFIG TABLE command
///
/// Factory Test handler for WRITE CONFIG TABLE
/// command. Writes the Radio Presets configuration
/// table passed as part of the command to flash.
/// Outputs over Factory Test Interface '.' on
/// success or 'X' on failure.

static void FACTORY_TEST_ComWriteConfigTable(void)
{
  unsigned char code radioPresetsHeader[RADIO_PRESETS_HEADER_SIZE] = {RADIO_PRESETS_ID_LSB,
                                                                      RADIO_PRESETS_ID_MSB,
                                                                      RADIO_PRESETS_VERSION_LSB,
                                                                      RADIO_PRESETS_VERSION_MSB
                                                                     };


  unsigned int  radioPresetsCrc;
  unsigned char status;
  unsigned char temp;
  unsigned long address;
  unsigned char i;

  address = RADIO_PRESETS_ADDR;

  status = SUCCESS;

  if (HAL_CommandBufferNumberOfArgs() == RADIO_PRESETS_VALUES_COUNT)
  {
    // Validate that requested radio presets are valid
    for (i = 0; i < RADIO_PRESETS_VALUES_COUNT; i++)
    {
      temp = HAL_UartGetHexPair(i + 2);

      if (FACTORY_TEST_RadioTypeIsValid(temp) == FALSE)
      {
        status = FAIL;
        break;
      }
    }
  }
  else
  {
    status = FAIL;
  }

  if (status == SUCCESS)
  {
    if (HAL_FlashEraseSector(RADIO_PRESETS_SECTOR) == SUCCESS)
    {
      // Write Radio Presets PDI values
      for (i = 0; i < RADIO_PRESETS_VALUES_COUNT; i++)
      {
        temp = HAL_UartGetHexPair(i + 2);

        status &= HAL_FlashWriteAndVerify(address, temp);

        // Radio presets are stored aligned to 16-bit words, so skip 2 bytes
        address += 2;
      }

      // Write Radio Presets PDI header
      for (i = 0; i < RADIO_PRESETS_HEADER_SIZE; i++)
      {
        status &= HAL_FlashWriteAndVerify(address, radioPresetsHeader[i]);

        address++;
      }

      if (status != FAIL)
      {
        radioPresetsCrc = FACTORY_TEST_CalculateRadioPresetsCrc();

        // Write Radio Presets PDI CRC
        temp = (unsigned char)((radioPresetsCrc & 0x00FF ));
        status &= HAL_FlashWriteAndVerify(address, temp);           // write crc LSB
        address++;

        temp = (unsigned char)((radioPresetsCrc & 0xFF00) >> 8);
        status &= HAL_FlashWriteAndVerify(address, temp);           // write crc MSB
      }
    }
    else
    {
      status = FAIL;
    }
  }

  if (status == SUCCESS)        // write the 7 ASCII hex pairs in the line buffer to FLASH at the position pointed to by the Address pointer
  {
    HAL_UartPutChar('.');       // signal to host that the program operation has successfully completed
  }
  else
  {
    HAL_UartPutChar('X');       // signal to the host that the program operation has failed
  }

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for READ CONFIGURATION STRING command
///
/// Factory Test handler for READ CONFIGURATION STRING
/// command. Outputs over the factory test interface
/// the LCU configuration string.

static void FACTORY_TEST_ComReadConfigurationString(void)
{
  unsigned char radioPresetsValid;
  unsigned char forcingBytesValid;
  unsigned int  crc;
  unsigned int  antennaTableCrc;
  unsigned long address;
  unsigned char temp;
  unsigned char i;

  radioPresetsValid = FACTORY_TEST_RadioPresetsIsValid();
  forcingBytesValid = FACTORY_TEST_ForcingBytesIsValid();

  crc = CRC16_INITIAL_VALUE;

  // Output the radio presets
  address = RADIO_PRESETS_ADDR;

  for (i = 0; i < RADIO_PRESETS_VALUES_COUNT; i++)
  {
    if (radioPresetsValid)
    {
      temp = HAL_FlashRead(address);
    }
    else
    {
      temp = RADIO_PRESETS_DEFAULT;
    }

    HAL_UartPrintHex((long)temp, 2);
    crc = crc16(crc, temp);

    // Radio presets are stored aligned to 16-bit words, so skip 2 bytes
    address += 2;
  }
  // Output the antenna tables CRCs
  for (i = 0; i < ANTENNA_TABLE_COUNT; i++)
  {
    antennaTableCrc = FACTORY_TEST_CalculateAntennaTableCrc(i);

    temp = (unsigned char)((antennaTableCrc & 0xFF00) >> 8);
    HAL_UartPrintHex((long)temp, 2);
    crc = crc16(crc, temp);

    temp = (unsigned char)(antennaTableCrc & 0x00FF);
    HAL_UartPrintHex((long)temp, 2);
    crc = crc16(crc, temp);
  }

  // Output the forcing bytes
  if (forcingBytesValid)
  {
    temp = HAL_FlashRead(FORCING_BYTES_ADDR + 1);
  }
  else
  {
    temp = FORCING_BYTES_DEFAULT_MSB;
  }

  HAL_UartPrintHex((long)temp, 2);
  crc = crc16(crc, temp);

  if (forcingBytesValid)
  {
    temp = HAL_FlashRead(FORCING_BYTES_ADDR);
  }
  else
  {
    temp = FORCING_BYTES_DEFAULT_LSB;
  }

  HAL_UartPrintHex((long)temp, 2);
  crc = crc16(crc, temp);

  HAL_UartPrintHex((long)crc, 4);

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for READ SOFTWARE PART NO command
///
/// Factory Test handler for READ SOFTWARE PART NO
/// command. Outputs over the factory test interface
/// the LCU software part number and issue number.

static void FACTORY_TEST_ComReadSoftwarePartNumber(void)
{
  HAL_UartPrintHex((long)SOFTWARE_PART_NUMBER,  4);
  HAL_UartPrintHex((long)SOFTWARE_ISSUE_NUMBER, 2);

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Handler for READ PLD PART NO command
///
/// Factory Test handler for READ PLD PART NO
/// command. Outputs over the factory test interface
/// the PLD firmware part number and issue number.

static void FACTORY_TEST_ComReadPldPartNumber(void)
{
  unsigned char registerValue;

  registerValue = HAL_PldReadLatch(PLD_REG_SOFTWARE_NO_MSB);
  HAL_UartPrintHex((long)registerValue, 2);

  registerValue = HAL_PldReadLatch(PLD_REG_SOFTWARE_NO_LSB);
  HAL_UartPrintHex((long)registerValue, 2);

  registerValue = HAL_PldReadLatch(PLD_REG_ISSUE_NUMBER);
  HAL_UartPrintHex((long)registerValue, 2);

  HAL_UartPutChar('\r');
  HAL_UartPutChar('\n');
}

/// \brief Checks if string matched unlock string
///
/// Checks if passed string matches the unlock string
/// required to unlock Factory Test Mode.
///
/// \return Returns '1' if string is unlock string,
///         otherwise '0'

static unsigned char FACTORY_TEST_IsUnlockString(unsigned char str[])
{
  unsigned char i;
  unsigned char status;
  code char UnlockString[] = "001020400055AAFF";    // DEVIATION - Rule 5.6.4 - "code" storage specifier used in place of const

  status = TRUE;

  for (i = 0; UnlockString[i] != '\0'; i++)
  {
    if (str[i+2] != UnlockString[i])
    {
      status = FALSE;
      break;
    }
  }

  return status;
}

/// \brief Checks if the passed Radio Type ID is valid
///
/// Checks if the passed Radio Type ID is valid.
///
/// \return Returns '1' if Radio Type ID is valid,
///         otherwise '0'

static unsigned char FACTORY_TEST_RadioTypeIsValid(unsigned char radioTypeId)
{
  // DEVIATION - Rule 5.6.4 - "code" storage specifier used in place of const
  code unsigned char ValidRadioTypes[] = {0x01, // ARC210 GEN 5/6 16-bit
                                            0x02, // R&S MR6000X
                                            0x04, // ARC210 GEN 5/6 18-bit
                                            0x08, // SRT651/SRT700
                                            0x10, // TRA60XX 16-bit
                                            0x14, // MXF-483/4, MXF455/6
                                            0x15, // ARC222
                                            0x16, // ARC231 16-bit
                                            0x18, // TRA60XX 17-bit
                                            0x1F, // ARC186
                                            0x20, // RT7000
                                            0x24, // ARC182
                                            0x25, // ARC201D
                                            0x26, // CNR9000
                                            0xFF  // Factory Test
                                           };
  const unsigned char RadioTypesCount = 15;
  unsigned char i;
  unsigned char valid;

  valid = FALSE;

  for (i = 0; i < RadioTypesCount; i++)
  {
    if (radioTypeId == ValidRadioTypes[i])
    {
      valid = TRUE;
      break;
    }
  }

  return valid;
}

/// \brief Checks if Radio Presets PDI is compatible & valid
///
/// Checks if Radio Presets PDI stored in flash is compatible
/// & valid. Compatibility is comfirmed by checking the ID
/// and version number stored in the Radio Presets PDI.
/// Validity is confirmed by checking CRC stored in the
/// Radio Presets PDI against calculated CRC.
///
/// \return Returns '1' if Radio Presets PDI is compatible
///         & valid

static unsigned char FACTORY_TEST_RadioPresetsIsValid(void)
{
  unsigned char readByte;
  unsigned char dataIsValid;
  unsigned long address;
  unsigned int  storedCrc;

  dataIsValid = TRUE;

  address = RADIO_PRESETS_HEADER_ADDR;

  // Read and check Radio Presets ID
  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != RADIO_PRESETS_ID_LSB)
  {
    dataIsValid = FALSE;
  }

  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != RADIO_PRESETS_ID_MSB)
  {
    dataIsValid = FALSE;
  }

  // Read and check Radio Presets Version
  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != RADIO_PRESETS_VERSION_LSB)
  {
    dataIsValid = FALSE;
  }

  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != RADIO_PRESETS_VERSION_MSB)
  {
    dataIsValid = FALSE;
  }

  // Read and check CRC
  readByte = HAL_FlashRead(address);      // read crc LSB
  address++;
  storedCrc = (unsigned int)readByte;

  readByte = HAL_FlashRead(address);      // read crc MSB

  storedCrc |= (unsigned int)readByte << 8;

  if (FACTORY_TEST_CalculateRadioPresetsCrc() != storedCrc)
  {
    dataIsValid = FALSE;
  }

  return dataIsValid;
}

/// \brief Checks if Forcing Bytes PDI is compatible & valid
///
/// Checks if Forcing Bytes PDI stored in flash is compatible
/// & valid. Compatibility is comfirmed by checking the ID
/// and version number stored in the Forcing Bytes PDI.
/// Validity is confirmed by checking CRC stored in the
/// forcing bytes PDI against calculated CRC.
///
/// \return Returns '1' if Forcing Bytes PDI is compatible
///         & valid

static unsigned char FACTORY_TEST_ForcingBytesIsValid(void)
{
  unsigned char readByte;
  unsigned char dataIsValid;
  unsigned long address;
  unsigned int  storedCrc;

  dataIsValid = TRUE;

  address = FORCING_BYTES_HEADER_ADDR;

  // Read and check Forcing Bytes Presets ID
  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != FORCING_BYTES_ID_LSB)
  {
    dataIsValid = FALSE;
  }

  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != FORCING_BYTES_ID_MSB)
  {
    dataIsValid = FALSE;
  }

  // Read and check Forcing Bytes Version
  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != FORCING_BYTES_VERSION_LSB)
  {
    dataIsValid = FALSE;
  }

  readByte = HAL_FlashRead(address);
  address++;

  if (readByte != FORCING_BYTES_VERSION_MSB)
  {
    dataIsValid = FALSE;
  }

  // Read and check CRC
  readByte = HAL_FlashRead(address);              // read crc LSB
  address++;
  storedCrc = (unsigned int)readByte;

  readByte = HAL_FlashRead(address);              // read crc MSB
  storedCrc |= (unsigned int)readByte << 8;

  if (FACTORY_TEST_CalculateForcingBytesCrc() != storedCrc)
  {
    dataIsValid = FALSE;
  }

  return dataIsValid;
}

/// \brief Calculates CRC-16 of LCU software
///
/// performs a CRC-16 on the whole 32K byte code
/// space of the microcontroller containing the
/// LCU software.
///
/// \return Returns the CRC-16 of the LCU software

static unsigned int FACTORY_TEST_CalculateMicroCrc(void)
{
  unsigned int crc;
  unsigned int i;
  unsigned char code *addressPtr;

  crc = CRC16_INITIAL_VALUE;

  for (i = 0 ; i <= MAX_CODE_BYTES; i++)
  {
    addressPtr = (char *)i;
    crc = crc16(crc, *addressPtr);
  }

  return crc;
}

/// \brief Calculates Antenna Table CRC using PLD
///
/// Calculates the Antenna Table CRC for the specified table
/// using the PLD. The PLD performs the CRC-16 check and places
/// the result into the Table CRC LSB & MSB registers.
///
/// \param antennaTable The number (0 to 3) of the Antenna Table
///        to calculate the CRC over.
///
/// \return CRC-16 of Antenna Table

static unsigned int FACTORY_TEST_CalculateAntennaTableCrc(unsigned char antennaTable)
{
  unsigned int crc;
  unsigned char crcControlRegValue;
  unsigned char numberOfAttempts;
  unsigned char status;
  unsigned char i;

  status = SUCCESS;

  crc = 0xFFFF;

  numberOfAttempts = 0;

  if(antennaTable <= 3)
  {
    // Shift antenna table number of position of Table1 & Table0
    // in the Antenna Table CRC control Register
    crcControlRegValue = antennaTable << 5;

    crcControlRegValue |= PLD_REG_CRC_CONTROL_CHECK_CRC;

    HAL_PldWriteLatch(PLD_REG_CRC_CONTROL, crcControlRegValue);

    for (i = 0; i < 50; i++)
    {
      HAL_Delay2ms();
    }


    do
    {
      HAL_Delay2ms();

      crcControlRegValue = HAL_PldReadLatch(PLD_REG_CRC_CONTROL);

      numberOfAttempts++;

      if (numberOfAttempts > TABLE_CRC_CALC_MAX_ATTEMPTS)
      {
        status = FAIL;
        break;
      }
    }
    while((crcControlRegValue & PLD_REG_CRC_CONTROL_CHECK_CRC) != 0);

    if (status == SUCCESS)
    {
      crc  = (unsigned int)HAL_PldReadLatch(PLD_REG_TABLE_CRC_LSB);
      crc |= (unsigned int)HAL_PldReadLatch(PLD_REG_TABLE_CRC_MSB) << 8;
    }
  }

  return crc;
}

/// \brief Calculates CRC-16 of Radio Presets
///
/// This Function performs a CRC on the Radio
/// Presets configuration block. The configuration
/// block is read by the PLD in 16 bit word mode.
///
/// \return Returns the CRC-16 of the Radio Presets

static unsigned int FACTORY_TEST_CalculateRadioPresetsCrc(void)
{
  unsigned int crc;
  unsigned char i;
  unsigned long address;

  crc = CRC16_INITIAL_VALUE;

  address = RADIO_PRESETS_ADDR;

  crc = crc16(crc, 0XFF);                               // put Test mode LSB through CRC (should always be 0xFF)
  crc = crc16(crc, 0XFF);                               // put Test mode MSB through CRC (should always be 0xFF)

  // Put Radio Preset values through CRC
  for (i = 0; i < RADIO_PRESETS_VALUES_COUNT; i++)
  {
    crc = crc16(crc, HAL_FlashRead(address));           // put LSB through CRC
    address++;

    crc = crc16(crc, HAL_FlashRead(address));           // put MSB through CRC (the MSB is unused and will always be 0xFF)
    address++;
  }

  // Put Radio Preset ID and version through CRC
  for (i = 0; i < RADIO_PRESETS_HEADER_SIZE; i++)
  {
    crc = crc16(crc, HAL_FlashRead(address));

    address++;
  }

  return crc;
}

/// \brief Calculates CRC-16 of the forcing bytes
///
/// This Function performs a CRC on the forcing bytes.
///
/// \return Returns the CRC-16 of the Radio Presets

static unsigned int FACTORY_TEST_CalculateForcingBytesCrc(void)
{
  unsigned int crc;
  unsigned char i;
  unsigned long address;

  crc = CRC16_INITIAL_VALUE;

  address = FORCING_BYTES_ADDR;

  for (i = 0; i < FORCING_BYTES_TABLE_SIZE; i++)
  {
    crc = crc16(crc, HAL_FlashRead(address));
    address++;
  }

  return crc;
}

/// \brief Calculates IBM/ANSI CRC-16
///
/// Function to perform a CRC-16 (IBM/ANSI algorithm,
/// polynomial 0x8005).
///
/// \param crcValue Initial value for the CRC
/// \param newByte Byte value to be incorporated into the CRC
///
/// \return Returns the current value of CRC

unsigned int crc16(unsigned int crcValue, unsigned char newByte)
{
  unsigned int crc;
  unsigned char i;

  crc = crcValue;

  crc ^= (unsigned int)newByte;     // XOR byte into least sig. byte of crc

  for (i = 8; i != 0; i--)          // Loop over each bit
  {
    if ((crc & 0x0001) != 0)        // If the LSB is set
    {
      crc >>= 1;                    // Shift right and XOR with polynomial
      crc ^= CRC16_POLYNOM;
    }
    else                            // else LSB is not set
    {
      crc >>= 1;                    // Just shift right
    }
  }

  return crc;
}
