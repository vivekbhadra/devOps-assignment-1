::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Coverage results export script
::     Export coverage results in coverage.rvd to text files
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

CALL env.bat

%RVSBIN%\covexport coverage.rvd --no-line-numbers --fmt text -o %BLD_ID%_coverage_results.txt
%RVSBIN%\covexport coverage.rvd --no-line-numbers --fmt src  -o %BLD_ID%_coverage_results_src.txt