@echo off 
echo.
setlocal EnableDelayedExpansion
title 7-1600 LCU Software Update
set folderpath=%cd%
set atmelflippath="C:\Program Files (x86)\Atmel\Flip 3.4.7\bin"

set comport=com1

if not "%1"=="" (
  set comport=%1
)

set hexfile=39594-E.hex

if not "%2"=="" (
  set hexfile=%2
)

echo COM Port: !comport!
echo Programming File: !hexfile!

if not exist "%folderpath%\!hexfile!" (	
  echo FAIL - Programming file !hexfile! not found
) else (			
  %atmelflippath%\batchisp -device AT89C51RD2 -hardware RS232 -port !comport! -baudrate 57600 -operation ERASE F BLANKCHECK LOADBUFFER !hexfile! ENAX2 ENABLJB PROGRAM VERIFY start reset 0
)
pause