::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
@echo off

IF "%1"=="" GOTO USAGE
IF "%2"=="" GOTO USAGE
IF "%3"=="" GOTO USAGE

CALL env.bat

@ECHO on
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Program target and run test
::    ...currently a manual process

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Read coverage map data from serial port, write to a file
:: serialcom_receiver.py params:           <port> <baud> <timeout secs> <output file>
%PYTHON% rvs\scripts\serialcom_receiver.py %1   9600   20             rvs_map_compressed.bin %2 || (goto ERROR)

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Process the map data file the format expected by traceutils...
::   ...for non-compressed map format
:: %PYTHON% rvs\map_restore.py rvs_map.bin
::   ...for compressed map format
@echo "[E179-COV-009] Start"
%PYTHON% rvs\scripts\map_decompress.py rvs_map_compressed.bin rvs_map.bin || (goto ERROR)
@echo "[E179-COV-009] End"

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Process the coverage map data file and generate a report using traceutils
%RVSBIN%\traceutils -f rvs\filters\byte_read.flt -f %BLD_DIR%\rvs_map.memdump.flt rvs_map.bin -o rvs_map.rpz || (goto ERROR)
%RVSBIN%\covparser --map --merge-results --test-id %3 --test-name TP%3 coverage.rvd rvs_map.rpz || (goto ERROR)

goto END

:USAGE

echo ERROR: Incorrect number of arguments, expected 3 arguments:
echo.
echo   run COM_PORT UNLOCK TEST_ID
echo.
echo   COM_PORT: Name of serial port e.g. COM1
echo   UNLOCK: 0 = do not send unlock code, 1 = do send unlock code, 2 = do send unlock and enter bootloader
echo   TEST_ID: Numberical ID for test (must be greater than 0) 

exit /B 1

:ERROR
echo ~~~~~~ ERROR OCCURRED ~~~~~~

exit /B 1

:END