::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Main build script
::     preprocess, instrument, compile & link software under test
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

CALL env.bat

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

@echo "[E179-COV-024] Start"
call clean.bat
dir
dir build
@echo "[E179-COV-024] End"

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Compiler tools
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Root path of the C51 compiler installation 
set C51=C:\Keil_v5\C51

:: Add Keil compiler bin directory to path 
set PATH=%C51%\BIN;%PATH%

:: Path to the Cx51 include files
set C51INC=%C51%\INC

:: Path to the Cx51 library files
set C51LIB=%C51%\LIB

:: Compiler binary & options
set CC=C51
set CC_OPTS=OPTIMIZE (2,SPEED) CODE TABS (2) INCDIR (rvs\rvslib)

:: Assembler binary and options
set ASM=A51
set ASM_OPTS=SET (SMALL) EP

:: Linker binary and options
set LINK=BL51
set LINK_OPTS=RAMSIZE(256) OVERLAY( ?PR?_HAL_UARTPUTCHAR?HAL !  * )

:: Hex output generator
set HEXGEN=OH51

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
echo =================================================== BUILD START ===================================================
@ECHO ON

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Software under test source files
set SRCS=main.c bit.c factory_test.c hal.c
set ASMS=startup.a51 assembler.asm

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Check the installed coverage map templates
@echo "[E179-COV-026] Start"
%PYTHON% rvs\scripts\check_templates.py %RVSBIN% 8051-dal-c-compact || (goto ERROR)
@echo "[E179-COV-026] End"

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Generate the preprocessed source files
FOR %%I in (%SRCS%) DO %CC% %%I PP (%BLD_DIR%\%%~nI.p) OBJECT (%BLD_DIR%\%%~nI.obj) %CC_OPTS% 

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Instrument the source files
FOR %%I in (%SRCS%) DO %RVSBIN%\cins -c rvs\rvslib\rvs_instr.h -c rvs\rvslib\rvs_ipoint.h --cext CX51 --coverage-map --exf %BLD_DIR%\exf.exf %BLD_DIR%\%%~nI.p --xsc %BLD_DIR%\%%~nI.xsc -o %BLD_DIR%\%%~nI.i || (goto ERROR)

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Comment the line numbers from the instrumented source files
::FOR %%I in (%SRCS%) DO %PYTHON% rvs\scripts\comment_pp_line_numbers.py %BLD_DIR%\%%~nI.i || (goto ERROR)

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Generate the RVD from the xsc's
set "XSCS="
for %%I in (%SRCS%) do call set XSCS=%%XSCS%% %BLD_DIR%\%%~nI.xsc
%RVSBIN%\xstutils -o coverage.rvd --no-root %XSCS% || (goto ERROR)

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Generate the coverage map file (compact or non-compact)
%RVSBIN%\rvdutils coverage.rvd --map-template 8051-dal-c-compact --coverage-map %BLD_DIR%\rvs_map.c || (goto ERROR)
::%RVSBIN%\rvdutils coverage.rvd --map-template 8051-dal-c --coverage-map %BLD_DIR%\rvs_map.c || (goto ERROR)

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Check the max i-point number does not specified limit
@echo "[E179-COV-028] Start"
%PYTHON% rvs\scripts\check_max_ipoint.py coverage.rvd %IPOINT_MAX% || (goto ERROR)
@echo "[E179-COV-028] End"

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Compile the C source files
FOR %%I in (%SRCS%) DO %CC% %BLD_DIR%\%%~nI.i PP (%BLD_DIR%\%%~nI.q) OBJECT (%BLD_DIR%\%%~nI.obj) %CC_OPTS%

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Compile the RVS source files
%CC% rvs\rvslib\rvs.c OBJECT (%BLD_DIR%\rvs.obj) %CC_OPTS%
%CC% %BLD_DIR%\rvs_map.c OBJECT (%BLD_DIR%\rvs_map.obj) %CC_OPTS% 

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Build the assembler
FOR %%I in (%ASMS%) DO %ASM% %%I OBJECT (%BLD_DIR%\%%~nI.obj) %ASM_OPTS%

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Generate the list of objects to pass to the linker
set "OBJS="
for %%I in (%SRCS%) do call set OBJS=%%OBJS%% %BLD_DIR%\%%~nI.obj,
for %%I in (%ASMS%) do call set OBJS=%%OBJS%% %BLD_DIR%\%%~nI.obj,
set OBJS=%OBJS% %BLD_DIR%\rvs.obj, %BLD_DIR%\rvs_map.obj

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Link final image
%LINK% %OBJS% TO %BLD_ID% %LINK_OPTS%

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Generate hex output file
%HEXGEN% %BLD_ID% HEXFILE (%BLD_ID%.hex)

::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Generate CRC-16 of image
%PYTHON% crc_of_hex_file.py %BLD_ID%.hex > %BLD_ID%.crc16 || (goto ERROR)

goto END

:ERROR
echo ~~~~~~ ERROR occurred in build.bat ~~~~~~

exit /B 1

:END