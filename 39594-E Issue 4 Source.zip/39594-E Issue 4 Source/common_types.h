////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 1
// Author           : T. J. Keen
// Date             : 13 June 2017
//
////////////////////////////////////////////////////////////////////////////////

#ifndef COMMON_TYPES_H
#define COMMON_TYPES_H

#define TRUE	1
#define	FALSE	0	

#define ON 		1
#define OFF 	0

#define SUCCESS	1
#define FAIL	0

#endif // COMMON_TYPES_H