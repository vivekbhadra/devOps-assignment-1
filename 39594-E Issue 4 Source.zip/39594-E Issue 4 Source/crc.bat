::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:: Prints the MODBUS CRC-16 of a hex file. Defaults to the build name specified in env.bat
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

call env.bat

set hexfile=%BLD_ID%.hex
set maximagesize=32768

if not "%1"=="" (
  set hexfile=%1
)

if not "%2"=="" (
  set maximagesize=%2
)

%PYTHON% crc_of_hex_file.py %hexfile% --maxsize %maximagesize% || (goto ERROR)

goto END

:ERROR
echo ~~~~~~ ERROR OCCURRED ~~~~~~

exit /B 1

:END