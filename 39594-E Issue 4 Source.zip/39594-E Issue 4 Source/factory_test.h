////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 4
// Author           : T. J. Keen
// Date             : 13 June 2017
//
////////////////////////////////////////////////////////////////////////////////

#ifndef FACTORY_TEST_H
#define FACTORY_TEST_H

////////////////////////////////////////////////////////////////////////////////
//
// Defines
//
////////////////////////////////////////////////////////////////////////////////

// CRC definitions
#define CRC16_POLYNOM                    0xA001U        ///< 0x8005 polynomial for CRC-16 calculation (reflected form for algorithm)
#define CRC16_INITIAL_VALUE              0xFFFFU

////////////////////////////////////////////////////////////////////////////////
//
// Public function prototype declarations
//
////////////////////////////////////////////////////////////////////////////////

void FACTORY_TEST_Run(void);

unsigned int crc16(unsigned int crcValue, unsigned char newByte);

#endif // FACTORY_TEST_H