////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 4
// Author           : T. J. Keen
// Date             : 13 June 2017
//
// Description      : Module factory_test.c provides a set of serial commands 
//                    to manipulate the LCU's hardware to allow control by ATE 
//                    during production test
//
//
////////////////////////////////////////////////////////////////////////////////

#include "factory_test.h"

#include "rvs.h"

#include "hal.h"
#include "common_types.h"

////////////////////////////////////////////////////////////////////////////////
//
// Defines
//
////////////////////////////////////////////////////////////////////////////////

// No defines

////////////////////////////////////////////////////////////////////////////////
//
// Global variables
//
////////////////////////////////////////////////////////////////////////////////

// No global variables

////////////////////////////////////////////////////////////////////////////////
//
// Functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Calculates IBM/ANSI CRC-16
///
/// Function to perform a CRC-16 (IBM/ANSI algorithm,
/// polynomial 0x8005).
///
/// \param crcValue Initial value for the CRC
/// \param newByte Byte value to be incorporated into the CRC
///
/// \return Returns the current value of CRC

unsigned int crc16(unsigned int crcValue, unsigned char newByte)
{
  unsigned int crc;
  unsigned char i;

  crc = crcValue;

  crc ^= (unsigned int)newByte;     // XOR byte into least sig. byte of crc

  for (i = 8; i != 0; i--)          // Loop over each bit
  {
    if ((crc & 0x0001) != 0)        // If the LSB is set
    {
      crc >>= 1;                    // Shift right and XOR with polynomial
      crc ^= CRC16_POLYNOM;
    }
    else                            // else LSB is not set
    {
      crc >>= 1;                    // Just shift right
    }
  }

  return crc;
}
