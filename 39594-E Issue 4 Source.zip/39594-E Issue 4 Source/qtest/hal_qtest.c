////////////////////////////////////////////////////////////////////////////////
//
//       COPYRIGHT 2017 CHELTON LTD TRADING AS COBHAM ANTENNA SYSTEMS
//                          ALL RIGHTS RESERVED
//
//   No part of this document may be photocopied or otherwise reproduced
//   without the prior permission in writing of Cobham Technical Services Ltd.
//   Such written permission must also be obtained before any part
//   of this document is stored in a retrieval system of whatsoever nature
//
////////////////////////////////////////////////////////////////////////////////
//
// Project Number   : 7-1600
// Project Title    : Logic Convertor Unit
// Project Client   : PV / Airbus Helicopters
//
////////////////////////////////////////////////////////////////////////////////
//
// LANGUAGE         : C90 (Keil C51)
// DEV ENVIRONMENT  : Windows 7 / Windows 10
// TARGET M/C & O/S : Atmel AT89LP 8051
//
////////////////////////////////////////////////////////////////////////////////
//
// Version          : Issue 1
// Author           : T. J. Keen
// Date             : 13 June 2017
//
// Description      : Module hal.c provides an abstraction layer to the LCU's hardware with a set of functions that perform the
//                    low level manipulation of the IC's on the various circuit boards
//
////////////////////////////////////////////////////////////////////////////////

#include "hal.h"
#include "common_types.h"

#include "reg51atlprb2.h"   // special function register declarations for micro

////////////////////////////////////////////////////////////////////////////////
//
// Local defines
//
////////////////////////////////////////////////////////////////////////////////

#define PLD_COMPAT_SOFTWARE_NO_MSB               0x9AU     // software library Number 39595-E
#define PLD_COMPAT_SOFTWARE_NO_LSB               0xABU
#define PLD_COMPAT_INTERFACE_VERSION             0x00U

#define WARM_START_CHECK_PATTERN                   0XAAU


// MemoryPldSelect options
#define SELECT_FLASH_MEMORY                      0
#define SELECT_PLD                               1

// Parallel flash device commands
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_1       0xAAU
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_2       0x55U
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_3       0x80U
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_4       0xAAU
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_5       0x55U
#define FLASH_COMMAND_SECTOR_ERASE_CYCLE_6       0x30U

#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_1       0xAAAU
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_2       0x1555U
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_3       0xAAAU
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_4       0xAAAU
#define FLASH_ADDRESS_SECTOR_ERASE_CYCLE_5       0x1555U

#define FLASH_COMMAND_CHIP_ERASE_CYCLE_1         0xAAU
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_2         0x55U
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_3         0x80U
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_4         0xAAU
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_5         0x55U
#define FLASH_COMMAND_CHIP_ERASE_CYCLE_6         0x10U

#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_1         0xAAAU
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_2         0x1555U
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_3         0xAAAU
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_4         0xAAAU
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_5         0x1555U
#define FLASH_ADDRESS_CHIP_ERASE_CYCLE_6         0xAAAU

#define FLASH_COMMAND_RESET_CYCLE_1              0xF0U

#define FLASH_ADDRESS_RESET_CYCLE_1              0x00U

#define FLASH_COMMAND_WRITE_CYCLE_1              0xAAU
#define FLASH_COMMAND_WRITE_CYCLE_2              0x55U
#define FLASH_COMMAND_WRITE_CYCLE_3              0xA0U

#define FLASH_ADDRESS_WRITE_CYCLE_1              0xAAAU
#define FLASH_ADDRESS_WRITE_CYCLE_2              0x1555U
#define FLASH_ADDRESS_WRITE_CYCLE_3              0xAAAU



////////////////////////////////////////////////////////////////////////////////
//
// Global variables
//
////////////////////////////////////////////////////////////////////////////////

// these globals are needed to provide the serial comms interrupt with storage accessible by the main program loop and to facilitate
// status signalling to the main loop

// Linear command receive buffer
unsigned char xdata commandBuffer[COMMAND_BUFFER_SIZE] _at_ COMMAND_BUFFER_START;

unsigned char commandBufferPos;
bit commandAvailable;                       // command received from controller flag
static bit commandStart;

// Circular transmit buffer
static unsigned char xdata transmitBuffer[TRANSMIT_BUFFER_SIZE] _at_ TRANSMIT_BUFFER_START;

static unsigned char transmitBufferInPtr;
static unsigned char transmitBufferOutPtr;

static unsigned int transmitBufferCount;
bit uartTxActive;


////////////////////////////////////////////////////////////////////////////////
//
// Initialisation
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Initialses the micro-controller periphals
///
/// Function initialises the micro-controller's memory,
/// I2C bus, SPI bus, Timer 0 and 1

void HAL_MicroInit(void)
{
  // HAL_Init Micro memories
  AUXR |= 0x15;                             // A0 = 1 activate ALE only for external memory access
  // EXTRAM = 0 Allow access to internal XRAM
  // XRS = 5 Enable the maximum 2048 bytes of XRAM

  // HAL_Init I2C bus
  SSCON |= 0x42;                            // enable I2C, clock divider 192 for a bus frequency of 76.8 KHz (14.7456 MHz/192)

  // HAL_Init SPI bus

  // set up SPI in master mode with Fclk Periph/8 as baud rate
  // P1.5(MISO) serial input
  // P1.7(MOSI) serial output
  SPCON |= 0x10;                                // select master mode (MSTR bit)
  SPCON |= 0x02;                                // Fclk Periph/8 = 14.7456/8 = 1.8432 MHz (23LC1024 Fmax = 20 MHz)
  SPCON |= 0x20;                                // we are not using P1.1 so is available as standard I/O pin
  SPCON &= ~0x08;                               // CPOL=0 SCLK low when idle
  SPCON &= ~0x04;                               // CPHA=0
  SPCON |= 0x40;                                // enable spi (SPEN bit)

  // HAL_Init timer 0 for LED flashing (14.7456 MHz oscillator frequency, X2/6 cycles)
  // 16 bit rollover occurs after
  ET0 = 0;                                  // disable timer 0 interrupt
  TR0  = 0;                                 // stop timer 0
  TMOD &= ~0x0F;                        // clear timer 0 mode bits
  TMOD |= 0x01;                         // put timer 0 into 16-bit auto-reload no prescaler

  TL0 = 0;                                  // HAL_Init 16 bit counter low register to 0
  TH0 = 0;                                  // HAL_Init 16 bit counter high register to 0

  TR0 = 1;                                  // start timer 0

  // HAL_Init timer 1 for a HAL_Delay2ms counter
  ET1 = 0;                                  // disable timer 1 interrupt
  TR1 = 0;                                  // make sure timer 1 is stopped
  TMOD &= ~0xF0;                        // clear timer 1 mode bits
  TMOD |= 0x10;                         // put timer 1 into 16-bit auto-reload no prescaler

  EA = 1;                                       // enable all interrupts
}

////////////////////////////////////////////////////////////////////////////////
//
// UART
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Initialses UART for requested baud rate
//
/// Initialses the UART for the requested baud rate
/// @ 14.7456 MHz oscillator frequency
///
/// \note that clock doubling is enabled
///
/// \param baud The baud rate for the UART
/// uses the global variables commandAvailable, transmitBufferInPtr,
/// transmitBufferOutPtr,transmitBufferCount and uartTxActive


void HAL_UartInit(unsigned char baud)
{
  unsigned char code Divisor[] = {0xA0,0xD0,0xE8,0xF0,0xF8}; // 9600,19200,38400,57600,115200

  REN =0;                                               // disable serial reception

  RCAP2L = Divisor[baud];                       // load divisor for required baud rate
  RCAP2H = 0xFF;

  T2CON = 0x34;                                   // Set TX and Rx clocks to use timer 2
  SCON  = 0x52;                                   // variable baud rate 8 bit uart,rx enabled,RI=0,TI=0

  // Initialise linear command buffer control registers
  commandStart = FALSE;
  commandAvailable = FALSE;

  // Initialise circular transmit buffer control variables
  transmitBufferInPtr  = 0;
  transmitBufferOutPtr = 0;
  transmitBufferCount = 0;
  uartTxActive = FALSE;

  ES=1;                                               // serial interrupt on
  REN=1;                                                // enable serial reception
}

/// \brief Places the passed character on UART transmit buffer
///
/// \param ch Character to place on UART transmit buffer
/// uses the global variables transmitBuffer,transmitBufferInPtr, transmitBufferCount

void HAL_UartPutChar(char ch)
{
  ES = 0;                                   // disable serial interrupt

  // Enqueue character to circular transmit buffer
  transmitBuffer[transmitBufferInPtr++] = ch;
  transmitBufferCount++;

  if (transmitBufferInPtr > (TRANSMIT_BUFFER_SIZE - 1))
  {
    transmitBufferInPtr = 0;
  }

  if (!uartTxActive)
  {
    TI = 1;
    uartTxActive = TRUE;
  }

  ES = 1;
}

/// \brief The UART interrupt service routine
///
/// The UART interrupt service routine. Transmits
/// any characters in circular transmit buffer.
/// Receives any characters into the linear command
/// buffer. The commandAvailable flag is set if the
/// command buffer contains a full command.
/// uses the global variables commandBuffer, commandAvailable,
/// transmitBuffer, transmitBufferOutPtr, transmitBufferCount, uartTxActive and commandBufferPos

void HAL_UartServicePort(void) interrupt 4
{
  char ch;

  if (TI)                                                         // if the transmit buffer is empty
  {
    TI = 0;

    if (transmitBufferCount > 0)                            // if there are one or more characters in the circular tx buffer
    {
      ch = transmitBuffer[transmitBufferOutPtr++];                  // get character at output buffer pointer
      SBUF = ch;                                              // load character from buffer to uart transmit buffer
      transmitBufferCount--;                                  // decrement the buffer character count

      if (transmitBufferOutPtr > (TRANSMIT_BUFFER_SIZE - 1))            // if the pointer has reached the buffer end
      {
        transmitBufferOutPtr = 0;                    // then reset it to the beginning of the buffer
      }
    }
    else
    {
      uartTxActive = FALSE;                             // flag that we are no longer outputing characters
    }
  }

  if (RI)                                                          // is this a receive character interrupt?
  {
    ch = SBUF;                                              // get receive character
    HAL_UartPutChar(ch);                                    // echo character

    if (ch == '!')                                        // is it the start command character?
    {
      commandStart = TRUE;                          // flag start of command
      commandBufferPos = 0;                             // reset write pointer to start of command buffer
    }
    else
    {
      if (commandStart)
      {
        if (ch == '\r')
        {
          commandBuffer[commandBufferPos] = '\r';
          commandAvailable = TRUE;
          commandStart = FALSE;
        }
        else
        {
          if (commandBufferPos < COMMAND_BUFFER_SIZE)       // if we have not gone past buffer end
          {
            commandBuffer[commandBufferPos] = ch;   // write character to command line buffer
            commandBufferPos++;
          }
        }
      }
    }

    RI = 0;
  }
}

////////////////////////////////////////////////////////////////////////////////
//
// PLD register access functions
//
////////////////////////////////////////////////////////////////////////////////

/// \brief Writes a byte to a PLD register
///
/// Function to write a byte to the PLD register
/// mapped to the specified address in memory.
///
/// \param address Memory-mapped address of register
/// \param value Byte value to write to PLD register

void HAL_PldWriteLatch(unsigned int address, unsigned char value)
{
  unsigned char xdata * data memPointer; // ptr in data to xdata unsigned char

  MemoryPldSelect = SELECT_PLD;                                             // select CPLD 8 bit Registers for addressing

  memPointer = (unsigned char xdata*)address;
  *memPointer = value;
}

/// \brief Reads a byte from a PLD register
///
/// Function to read a byte from the PLD register
/// mapped to the specified address in memory.
///
/// \param address Memory-mapped address of register
///
/// \return byte value read from PLD register

unsigned char HAL_PldReadLatch(unsigned int address)
{
  unsigned char xdata * data memPointer;
  unsigned char value;

  MemoryPldSelect = SELECT_PLD;

  memPointer = (unsigned char xdata*)address;
  value = *memPointer;

  return value;
}

/// \brief Sets the specified bit(s) to the PLD register
///
/// Function to set a specific bit(s) within one of the PLD's
/// registers whilst preserving the value of the remaining
/// bits within the register. This function first reads the
/// PLD register, applies the bit mask and then writes the
/// resulting value back to the PLD.
///
/// \param address Memory-mapped address of register
/// \param mask of bits to set in register

void HAL_PldLatchSetBitMask(unsigned int address, unsigned char mask)
{
  unsigned char registerValue;

  registerValue = HAL_PldReadLatch(address);

  registerValue |= mask;

  HAL_PldWriteLatch(address, registerValue);
}

/// \brief Waits for 2ms
///
/// function waits for 2ms using Timer 1.
/// Timer 1 in compatibility and X2 modes counts at
/// 1/6 of the oscillator frequency  :
///   14.7456 MHz/6 = 2.4576 MHz
///   1 / 2.4576 MHz = 0.406uS tick
///   2ms /0.406uS ticks = 4915
///   65535 - 4915 = 60620 = 0xECCC

void HAL_Delay2ms(void)
{
  TR1 = 0;                  // stop timer 1 counting

  TH1 = 0xEC;               // set the timer 1 counters
  TL1 = 0xCC;

  TF1 = 0;                  // clear the overflow flag
  TR1 = 1;                  // start timer 1 counting

  while (!TF1)
  {
    // No operation
  }

  TR1 = 0;                  // stop timer 1 counting
}

/// \brief function to wait for the PLD to initialise
///
// The CPLD has a delayed initialisation due to the 1.8V core voltages slow rise time because of the brown-out hold-up capacitance charging
// The CPLD sets the "CpldReady" line low to notify the microcontroller that it has loaded its image and initialised itself.
// All pins of the CPLD default to input with weak pull-up when the device is unprogrammed (so signalling "not ready")
//
// A timeout of 2 seconds is allowed before the code halts and routes the JTAG chain to J1
// This is done in order that a unit can be recovered if the CPLD programming fails after device erasure

void HAL_PldWaitForReady(void)
{
  while (CpldReady == 1)      // while the CPLD output is in the power-up state of input with pull-up
  {
  }
}

