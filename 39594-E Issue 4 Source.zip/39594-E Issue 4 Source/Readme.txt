					
					Firmware for Assy 39647 Digital PCB  
                              
Release Notes
-------------

Software Item Number: 		39594-E
Software Author: 		T. J. Keen


Readme version history
----------------------

Readme.txt Author: 		T. J. Keen


Software Description.
---------------------

This firmware is loaded into the P89LP51RD2 Microcontroller on Assy No. 39647 via 39647-PTS.
Assy No. 39647 is a subassembly of the 7-1600 Logic convertor unit.


Distributed files.
------------------

assembler.asm
bit.c
bit.h
build.bat
build_minimal.bat
build_qtest.bat
clean.bat
common_types.h
crc.bat
crc_of_hex_file.py
env.bat
export_coverage.bat
factory_test.c
factory_test.h
hal.c
hal.h
Logic Unit.uvop
Logic Unit.uvpr
main.c
program.bat
Readme.txt
reg51atlprb2.h
run.bat
startup.a51
readme.txt - This file
qtest/factory_test_qtest.c
qtest/hal_qtest.c
qtest/oracle_rpc_qtest_c.txt
qtest/oracle_rpc_qtest_src_c.txt
qtest/rvs_qtest_main.c
qtest/rvs_rpc_qtest_c.c
qtest/rvs_rpc_qtest_c.h
rvs/covmap/template_c_normal_c.template
rvs/covmap/template_c_normal_h.template
rvs/filters/byte_read.flt
rvs/rvslib/rvs.c
rvs/rvslib/rvs.h
rvs/rvslib/rvs_instr.h
rvs/rvslib/rvs_instr_qtest.h
rvs/rvslib/rvs_ipoint.h
rvs/script/check_max_ipoint.py
rvs/script/check_templates.py
rvs/script/comment_pp_line_numbers.py
rvs/script/map_decompress.py
rvs/script/map_restore.py
rvs/script/serialcom_receiver.py


Installation / Loading
----------------------

This firmware is compiled using Keil uVision IDE-Version V5.20.0.39

Tool Version Numbers:

Toolchain:        	PK51 Prof. Developers Kit  	V9.56.0.0
C Compiler:         	C51.exe    			V9.56.0.0
Assembler:          	A51.exe    			V8.2.5.0
Linker/Locator:     	BL51.exe    			V6.22
Librarian:             	LIB51.exe    			V4.30.1.0
Hex Converter:      	OH51.exe    			V2.7.0.0
CPU DLL:               	S8051.DLL            		V3.106.0.0
Dialog DLL:         	DP51.DLL             		V2.63.0.0

The software should be built using the build_minimal.bat DOS script

This firmware is loaded using the QX258 in conjunction with Atmel Flip 3.4.7 at board level during the PTS.
It can also be loaded to the fully assembled Logic Unit using the factory configuration tool 39597-E.


Other useful information
------------------------



                                          Revision History
					  ----------------

ISSUE 1 ISSUED ON   28/11/17 (ECN N/A)
FIRST ISSUE UNDER FORMAL CONTROL.
CRC-16 DF0E (32K FF Fill)

ISSUE 2 ISSUED ON   18/01/18 (CR 39,054 )
CRC-16 DD39 (32K FF Fill)

ISSUE 3 ISSUED ON   17/04/18 (CR 39,203 )
CRC-16 793A (32K FF Fill)

Changes from issue 2:

1) Added new function HAL_FlushCommandBuffer()
2) Added new function HAL_CommandBufferNumberOfArgs()
3) Now test for the correct number of arguments passed to command processor commands.
4) Improved robustness of command function FACTORY_TEST_ComSetJ1FaultOutput() to invalid command parameters.
5) Improved robustness of command function FACTORY_TEST_ComConfigureRadioDataInputs() to invalid command parameters.
6) Improved robustness of command function HAL_FlashWrite() with addition of address range check.
7) Fixed Re-factoring bug in HAL_FlashEraseSector().
8) Improved robustness of command function HAL_SetInputLed() to invalid command parameters.
9) Improved robustness of command function HAL_SetOutputLed() to invalid command parameters.
10) FACTORY_TEST_TryUnlock() should turn off Input LED
11) FACTORY_TEST_ComSetJ1FaultOutput() 01 should set J1, pin F to GND
12) FACTORY_TEST_ComMicroBootloader() <CR> moved to end of string for compatibility with loader tool
13) FACTORY_TEST_CalculateRadioPresetsCrc() Now includes test mode bytes(0xFF)
14) FACTORY_TEST_CalculateForcingBytesCrc() Comments corrected

ISSUE 4 ISSUED ON   2/08/18 (CR 39,466)
CRC-16 FD1E (32K FF Fill)

Changes from issue 3:

1) Addresses software coding standard compliance issues
2) Added code coverage integration
3) Corrected order of warm start check so that factory test mode is checked first

- END OF FILE -
