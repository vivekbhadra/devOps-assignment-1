##############################################################################
#    COPYRIGHT 2018 CHELTON LTD TRADING AS COBHAM AEROSPACE CONNECTIVITY
#                          ALL RIGHTS RESERVED
#
#   No part of this document may be photocopied or otherwise reproduced
#   without the prior permission in writing of Cobham Technical Services Ltd.
#   Such written permission must also be obtained before any part
#   of this document is stored in a retrieval system of whatsoever nature
#
##############################################################################
#
# Description: Script to calculate and output the MODEBUS CRC-16 for a file
#
##############################################################################

from PyCRC.CRC16 import CRC16
import argparse
import sys
from intelhex import IntelHex

def parse_cmdline():
   parser = argparse.ArgumentParser(description='Generates the MODBUS CRC-16 for a file')
   parser.add_argument('file', help='File to generate CRC for')
   parser.add_argument('--maxsize', type=int,help='Maximum size of image', default=32768)
   args = parser.parse_args()
   return args

try:
    args = parse_cmdline()

    ih = IntelHex()
    ih.loadhex(args.file) 
    data = ih.tobinstr() 

    if len(data) > args.maxsize:
        sys.stderr.write("File is larger than micro's program space\n")
        sys.exit(1)

    paddingLength = args.maxsize - len(data)
    
    # Pad the data to the size of the micro's program space
    data = data + b'\xFF' * paddingLength

    crc = CRC16(modbus_flag=True).calculate(data)

    sys.stdout.write(f'{crc:X}')

except Exception as inst:
    sys.stderr.write("Error in generate_crc.py\n")
    sys.stderr.write(str(type(inst)))
    sys.stderr.write(str(inst.args))
    sys.stderr.write(str(inst))
    sys.exit(1)
